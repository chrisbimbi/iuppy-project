import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:iuppy_app/core/providers.dart';
import 'package:iuppy_app/features/chat/chat_service.dart';
import 'package:intl/intl.dart';
import 'package:file_picker/file_picker.dart';
import 'package:record/record.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class ChatRoomPage extends HookConsumerWidget {
  final String conversationId;
  final String? title;

  const ChatRoomPage({
    super.key,
    required this.conversationId,
    this.title,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final chatService = ref.watch(chatServiceProvider);
    final api = ref.watch(apiClientProvider);
    final user = ref.watch(userProfileProvider).value;
    
    final messages = useState<List<Map<String, dynamic>>>([]);
    final isLoading = useState(true);
    final inputCtrl = useTextEditingController();
    final scrollCtrl = useScrollController();
    
    // Reply State
    final replyingTo = useState<Map<String, dynamic>?>(null);
    
    // Recording State
    final isRecording = useState(false);
    final recordingStart = useState<DateTime?>(null);
    final audioRecorder = useMemoized(() => AudioRecorder());
    final audioPlayer = useMemoized(() => AudioPlayer());
    final hasText = useState(false);

    useEffect(() {
      final listener = () {
        hasText.value = inputCtrl.text.isNotEmpty;
      };
      inputCtrl.addListener(listener);
      return () => inputCtrl.removeListener(listener);
    }, [inputCtrl]);

    // Load initial history
    useEffect(() {
      chatService.joinRoom(conversationId);
      
      api.getChatMessages(conversationId).then((data) {
          if (context.mounted) {
             messages.value = data;
             isLoading.value = false;
          }
      }).catchError((e) {
         debugPrint('Error fetching history: $e');
         isLoading.value = false;
      });

      final sub = chatService.messageStream.listen((msg) {
        if (msg['conversationId'] == conversationId) {
           // Handle Update (e.g. Reaction or Edit)
           if (msg['isUpdate'] == true || messages.value.any((m) => m['id'] == msg['id'] && m['isPending'] != true)) {
              final index = messages.value.indexWhere((m) => m['id'] == msg['id']);
              if (index != -1) {
                 final list = List<Map<String, dynamic>>.from(messages.value);
                 list[index] = msg;
                 messages.value = list;
                 return;
              }
           }

           // Handle New Message
           // Check dedupe against pending
           final pendingIndex = messages.value.indexWhere((m) => 
               m['isPending'] == true && 
               m['content'] == msg['content'] && 
               m['senderId'] == msg['senderId']
           );
           
           if (pendingIndex != -1) {
               final newList = List<Map<String, dynamic>>.from(messages.value);
               newList[pendingIndex] = msg;
               messages.value = newList;
           } else {
               messages.value = [msg, ...messages.value];
           }
        }
      });

      return () {
        sub.cancel();
        chatService.leaveRoom(conversationId);
        audioRecorder.dispose();
        audioPlayer.dispose();
      };
    }, [conversationId]);

    Future<void> _sendMessage(String content, String type, {Map<String, dynamic>? metadata}) async {
       if (content.isEmpty) return;
       
       final tempId = DateTime.now().millisecondsSinceEpoch.toString();
       final replyId = replyingTo.value?['id'];

       // Create Snapshot for optimistic UI
       Map<String, dynamic>? replySnapshot;
       if (replyingTo.value != null) {
          replySnapshot = {
            'id': replyingTo.value!['id'],
            'content': replyingTo.value!['content']?.substring(0, 100) ?? '...',
            'senderName': '...', // Name resolution tricky here optimistically without map
          };
       }

       final optimisticMsg = {
         'id': tempId,
         'conversationId': conversationId,
         'senderId': user?.id,
         'content': content,
         'type': type,
         'metadata': metadata,
         'createdAt': DateTime.now().toIso8601String(),
         'isPending': true, 
         'replyToId': replyId,
         'replySnapshot': replySnapshot
       };
       
       messages.value = [optimisticMsg, ...messages.value];
       replyingTo.value = null; // Clear reply
       
       chatService.sendMessage(conversationId, content, type: type, metadata: metadata, replyToId: replyId);
    }

    void sendText() {
      final text = inputCtrl.text.trim();
      if (text.isEmpty) return;
      _sendMessage(text, 'TEXT');
      inputCtrl.clear();
    }

    Future<void> pickAndUploadFile() async {
      // ... (File picking logic same as before, omitted for brevity, keeping existing)
      // Re-implementing simplified to save tokens but must keep existing logic working
      // I will just copy the existing logic or reference it... 
      // Since I am replacing the whole build, I must include it.
      
      final type = await showModalBottomSheet<String>(
         context: context,
         builder: (ctx) => SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                 ListTile(leading: const Icon(Icons.camera_alt), title: const Text('Câmera'), onTap: () => Navigator.pop(ctx, 'camera')),
                 ListTile(leading: const Icon(Icons.photo_library), title: const Text('Galeria'), onTap: () => Navigator.pop(ctx, 'gallery')),
                 ListTile(leading: const Icon(Icons.insert_drive_file), title: const Text('Arquivo'), onTap: () => Navigator.pop(ctx, 'file')),
              ],
            )
         )
      );
      if (type == null) return;
      
      try {
        FilePickerResult? result;
        if (type == 'file') {
             result = await FilePicker.platform.pickFiles(allowMultiple: false, type: FileType.any);
        } else {
             Map<String, FileType> map = {'gallery': FileType.image, 'camera': FileType.image};
             result = await FilePicker.platform.pickFiles(allowMultiple: false, type: map[type] ?? FileType.any);
        }

        if (result != null && result.files.isNotEmpty) {
           final file = result.files.first;
           final bytes = File(file.path!).readAsBytesSync();
           final url = await api.uploadFileBytes(bytes, file.name);
           final msgType = ['jpg','jpeg','png','gif'].contains(file.extension?.toLowerCase()) ? 'IMAGE' : 'FILE';
           _sendMessage(url, msgType, metadata: {'fileName': file.name, 'fileSize': file.size});
        }
      } catch (e) {
        debugPrint('Error picking file: $e');
      }
    }

    Future<void> stopRecording(bool cancel) async {
       if (!isRecording.value) return; // Prevent double stop
       final path = await audioRecorder.stop();
       isRecording.value = false;
       final duration = recordingStart.value != null 
          ? DateTime.now().difference(recordingStart.value!).inMilliseconds 
          : 0;
       
       if (!cancel && path != null && duration > 1000) { // Min 1 sec
          final file = File(path);
          final bytes = await file.readAsBytes();
          final url = await api.uploadFileBytes(bytes, 'voice_message.m4a');
          _sendMessage(url, 'VOICE', metadata: {'duration': duration});
       }
    }

    Future<void> startRecording() async {
      if (await Permission.microphone.request().isGranted) {
        final dir = await getTemporaryDirectory();
        final path = '${dir.path}/audio_${DateTime.now().millisecondsSinceEpoch}.m4a';
        await audioRecorder.start(const RecordConfig(), path: path);
        isRecording.value = true;
        recordingStart.value = DateTime.now();
        
        // Auto-stop after 2 mins
        Future.delayed(const Duration(minutes: 2), () {
            if (isRecording.value) stopRecording(false);
        });
      }
    }
    
    void onReply(Map<String, dynamic> msg) {
        replyingTo.value = msg;
        // Focus input?
    }
    
    void onReact(String msgId, String reaction) {
        chatService.sendReaction(conversationId, msgId, reaction);
        Navigator.pop(context); // Close sheet
    }

    return Scaffold(
      appBar: AppBar(
          title: Text(title ?? 'Chat'),
          actions: [
             IconButton(
                 icon: const Icon(Icons.info_outline),
                 onPressed: () {
                     // Pass title to info page
                     final encodedTitle = Uri.encodeComponent(title ?? 'Info');
                     context.push('/chat/$conversationId/info?title=$encodedTitle');
                 }
             )
          ],
      ),
      body: Column(
        children: [
          Expanded(
            child: isLoading.value 
               ? const Center(child: CircularProgressIndicator())
               : ListView.builder(
                   controller: scrollCtrl,
                   reverse: true,
                   itemCount: messages.value.length,
                   itemBuilder: (context, index) {
                     final msg = messages.value[index];
                     final isMe = msg['senderId'] == user?.id;
                     return _MessageBubble(
                       message: msg,
                       isMe: isMe,
                       player: audioPlayer,
                       onReply: () => onReply(msg),
                       onReact: (r) => onReact(msg['id'], r),
                     );
                   },
               ),
          ),
          _ChatInput(
            controller: inputCtrl,
            isRecording: isRecording.value,
            recordingDuration: recordingStart.value != null ? DateTime.now().difference(recordingStart.value!).inSeconds : 0, 
            replyingTo: replyingTo.value,
            onCancelReply: () => replyingTo.value = null,
            onSendText: sendText,
            onAttachment: pickAndUploadFile,
            onRecordStart: startRecording,
            onRecordStop: () => stopRecording(false),
            onRecordCancel: () => stopRecording(true),
            showSendButton: hasText.value,
          ),
        ],
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final Map<String, dynamic> message;
  final bool isMe;
  final AudioPlayer player;
  final VoidCallback onReply;
  final Function(String) onReact;

  const _MessageBubble({
    required this.message,
    required this.isMe,
    required this.player,
    required this.onReply,
    required this.onReact,
  });
  
  void _showMenu(BuildContext context) {
      showModalBottomSheet(context: context, builder: (ctx) {
          return SafeArea(
              child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                      Container(
                          padding: const EdgeInsets.all(16),
                          child: Wrap(
                              spacing: 16,
                              children: ['👍','❤️','😂','😮','😢','😡']
                                .map((e) => GestureDetector(
                                    onTap: () => onReact(e),
                                    child: Text(e, style: const TextStyle(fontSize: 32)),
                                )).toList(),
                          ),
                      ),
                      const Divider(),
                      ListTile(
                          leading: const Icon(Icons.reply),
                          title: const Text('Responder'),
                          onTap: () {
                              Navigator.pop(ctx);
                              onReply();
                          },
                      )
                  ]
              )
          );
      });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final type = message['type'] ?? 'TEXT';
    final content = message['content'];
    final meta = message['metadata'] ?? {};
    final time = message['createdAt'];
    final isPending = message['isPending'] == true;
    final replyTo = message['replySnapshot'];
    final reactions = message['reactions'] as Map<String, dynamic>?;

    Widget body;
    switch (type) {
      case 'IMAGE':
        body = ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.network(content, width: 200, fit: BoxFit.cover),
        );
        break;
      case 'VOICE':
        body = Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.play_arrow),
              onPressed: () => player.play(UrlSource(content)),
              color: isMe ? Colors.white : Colors.black87,
            ),
            Text('Áudio', style: TextStyle(color: isMe ? Colors.white : Colors.black87)),
          ],
        );
        break;
      case 'FILE':
        body = Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.insert_drive_file, color: isMe ? Colors.white : Colors.black54),
            const SizedBox(width: 8),
            Flexible(
               child: Text(
                 meta['fileName'] ?? 'Arquivo',
                 style: TextStyle(color: isMe ? Colors.white : Colors.black87, decoration: TextDecoration.underline),
               ),
            ),
          ],
        );
        break;
      default:
        body = Text(
          content,
          style: theme.textTheme.bodyMedium?.copyWith(color: isMe ? Colors.white : Colors.black87),
        );
    }

    return GestureDetector(
      onLongPress: () => _showMenu(context),
      // Swipe to reply could also be here using Dismissible
      child: Dismissible(
          key: Key('msg_${message['id']}'),
          direction: DismissDirection.startToEnd,
          confirmDismiss: (_) async {
              onReply();
              return false;
          },
          background: Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.only(left: 20),
              child: const Icon(Icons.reply, color: Colors.grey),
          ),
          child: Align(
            alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              child: Column(
                  crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      decoration: BoxDecoration(
                        color: isMe ? theme.primaryColor : Colors.grey.shade200,
                        borderRadius: BorderRadius.only(
                          topLeft: const Radius.circular(16),
                          topRight: const Radius.circular(16),
                          bottomLeft: isMe ? const Radius.circular(16) : Radius.circular(0),
                          bottomRight: isMe ? const Radius.circular(0) : const Radius.circular(16),
                        ),
                      ),
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (replyTo != null)
                             Container(
                                 margin: const EdgeInsets.only(bottom: 6),
                                 padding: const EdgeInsets.all(8),
                                 decoration: BoxDecoration(
                                     color: Colors.black.withOpacity(0.1),
                                     borderRadius: BorderRadius.circular(8),
                                     border: Border(left: BorderSide(color: isMe ? Colors.white : theme.primaryColor, width: 3))
                                 ),
                                 child: Column(
                                     crossAxisAlignment: CrossAxisAlignment.start,
                                     children: [
                                         Text(replyTo['senderName'] ?? 'No Name', 
                                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 10, color: isMe ? Colors.white70 : Colors.black87)),
                                         Text(replyTo['content'] ?? '', 
                                            maxLines: 1, overflow: TextOverflow.ellipsis,
                                            style: TextStyle(fontSize: 12, color: isMe ? Colors.white70 : Colors.black87)),
                                     ],
                                 ),
                             ),
                        
                          body,
                          
                          const SizedBox(height: 4),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              if (time != null)
                                Text(
                                  DateFormat('HH:mm').format(DateTime.parse(time)),
                                  style: theme.textTheme.bodySmall?.copyWith(
                                    color: isMe ? Colors.white70 : Colors.black54,
                                    fontSize: 10,
                                  ),
                                ),
                              if (isPending) ...[
                                 const SizedBox(width: 4),
                                 const Icon(Icons.access_time, size: 10, color: Colors.white70),
                              ]
                            ],
                          ),
                        ],
                      ),
                    ),
                    if (reactions != null && reactions.isNotEmpty)
                        Padding(
                            padding: const EdgeInsets.only(top: 2),
                            child: Wrap(
                                spacing: 4,
                                children: reactions.entries.map((entry) {
                                    final list = entry.value as List;
                                    final count = list.length;
                                    return GestureDetector(
                                        onTap: () {
                                            showModalBottomSheet(context: context, builder: (ctx) {
                                                return Container(
                                                   padding: const EdgeInsets.all(16),
                                                   child: Column(
                                                      mainAxisSize: MainAxisSize.min,
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                         Text('${entry.key} Reações ($count)', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                                                         const SizedBox(height: 10),
                                                         ConstrainedBox(
                                                           constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.4),
                                                           child: ListView(
                                                              shrinkWrap: true,
                                                              children: list.map((u) {
                                                                  final name = (u is Map) ? (u['name'] ?? 'Usuário') : 'Usuário';
                                                                  return ListTile(
                                                                      contentPadding: EdgeInsets.zero,
                                                                      leading: CircleAvatar(child: Text(name[0].toUpperCase())),
                                                                      title: Text(name),
                                                                  );
                                                              }).toList(),
                                                           ),
                                                         )
                                                      ],
                                                   ),
                                                );
                                            });
                                        },
                                        child: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                            decoration: BoxDecoration(
                                                color: Colors.grey.shade200,
                                                borderRadius: BorderRadius.circular(12),
                                                border: Border.all(color: Colors.white, width: 1)
                                            ),
                                            child: Text('${entry.key} $count', style: const TextStyle(fontSize: 10)),
                                        ),
                                    );
                                }).toList()
                            ),
                        )
                  ]
              ),
            ),
          )
      ),
    );
  }
}

class _ChatInput extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onSendText;
  final VoidCallback onAttachment;
  final VoidCallback onRecordStart;
  final VoidCallback onRecordStop;
  final VoidCallback onRecordCancel;
  final bool isRecording;
  final int recordingDuration; // Mock, real requires timer in parent or here
  final Map<String, dynamic>? replyingTo;
  final VoidCallback onCancelReply;
  final bool showSendButton;

  const _ChatInput({
    required this.controller,
    required this.onSendText,
    required this.onAttachment,
    required this.onRecordStart,
    required this.onRecordStop,
    required this.onRecordCancel,
    required this.isRecording,
    this.recordingDuration = 0,
    this.replyingTo,
    required this.onCancelReply,
    required this.showSendButton,
  });

  @override
  Widget build(BuildContext context) {
    if (isRecording) {
      return Dismissible(
         key: const ValueKey('recording'),
         direction: DismissDirection.endToStart,
         onDismissed: (_) => onRecordCancel(),
         child: Container(
             padding: const EdgeInsets.all(16),
             color: Colors.red.shade50,
             child: Row(
               children: [
                 const Icon(Icons.mic, color: Colors.red, key: ValueKey('mic_active')),
                 const SizedBox(width: 8),
                 // In a real app we'd need a Timer widget here update every second
                 const Text('Gravando... < 2:00', style: TextStyle(color: Colors.red)), 
                 const Spacer(),
                 const Text('Deslize para cancelar', style: TextStyle(color: Colors.grey)),
                 const SizedBox(width: 10),
                 const Icon(Icons.chevron_left, color: Colors.grey),
               ],
             ),
         ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 4,
            offset: const Offset(0, -2),
          )
        ],
      ),
      child: Column(
        children: [
          if (replyingTo != null)
             Container(
                 padding: const EdgeInsets.all(8),
                 color: Colors.grey.shade100,
                 child: Row(
                     children: [
                         const Icon(Icons.reply, size: 16, color: Colors.grey),
                         const SizedBox(width: 8),
                         Expanded(
                             child: Column(
                                 crossAxisAlignment: CrossAxisAlignment.start,
                                 children: [
                                     Text('Respondendo a ${replyingTo!['senderName'] ?? '...'}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                                     Text(replyingTo!['content'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                                 ],
                             )
                         ),
                         IconButton(icon: const Icon(Icons.close, size: 16), onPressed: onCancelReply)
                     ],
                 ),
             ),
          
          SafeArea(
            child: Container(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.attach_file),
                    onPressed: onAttachment,
                  ),
                   Expanded(
                    child: TextField(
                      controller: controller,
                      decoration: InputDecoration(
                        hintText: 'Digite uma mensagem...',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide.none,
                        ),
                        filled: true,
                        fillColor: Colors.grey.shade100,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      ),
                      textCapitalization: TextCapitalization.sentences,
                      onSubmitted: (_) => onSendText(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  
                  // Toggle Mic vs Send
                  if (showSendButton)
                    IconButton(
                        icon: const Icon(Icons.send_rounded),
                        color: Theme.of(context).primaryColor,
                        onPressed: onSendText,
                    )
                  else
                    GestureDetector(
                         onLongPressStart: (_) => onRecordStart(),
                         onLongPressEnd: (_) => onRecordStop(),
                         child: CircleAvatar(
                             backgroundColor: Theme.of(context).primaryColor,
                             child: const Icon(Icons.mic, color: Colors.white),
                         ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

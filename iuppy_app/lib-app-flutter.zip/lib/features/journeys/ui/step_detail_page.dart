import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html_core/flutter_widget_from_html_core.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:iuppy_app/features/gamification/ui/xp_award_dialog.dart';
import 'package:iuppy_app/features/journeys/data/journey_service.dart';
import 'package:iuppy_app/features/forms/widgets/form_renderer.dart';
import 'package:iuppy_app/features/surveys/widgets/survey_renderer.dart';
import 'package:iuppy_app/features/forms/providers/forms_storage_provider.dart';
import 'package:iuppy_app/core/providers.dart';
import '../journey_providers.dart';
import 'package:url_launcher/url_launcher.dart';

class StepDetailPage extends ConsumerStatefulWidget {
  final String journeyId;
  final String stepId;

  const StepDetailPage({
    super.key,
    required this.journeyId,
    required this.stepId,
  });

  @override
  ConsumerState<StepDetailPage> createState() => _StepDetailPageState();
}

class _StepDetailPageState extends ConsumerState<StepDetailPage> {
  bool _isLoading = false;
  Map<String, dynamic>? _stepData;
  String? _errorMessage;
  bool _ackChecked = false;

  @override
  void initState() {
    super.initState();
    _fetchStepDetails();
  }

  Future<void> _fetchStepDetails() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      final step = await ref.read(journeyServiceProvider).getStepDetails(widget.journeyId, widget.stepId);
      setState(() {
        _stepData = step;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Erro ao carregar detalhes do passo: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _completeStep() async {
    setState(() => _isLoading = true);
    try {
      await ref.read(journeyServiceProvider).completeStep(widget.journeyId, widget.stepId);
      if (mounted) {
        // Show XP Award Dialog
        await XPAwardDialog.show(context, 10); // 10 XP base
        
        if (mounted) {
          context.pop();
          // Refresh progress
          ref.invalidate(journeyProgressProvider);
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao concluir passo: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final textPrimary = colorScheme.onSurface;
    final background = colorScheme.surface;

    if (_isLoading && _stepData == null) {
      return Scaffold(
        backgroundColor: background,
        appBar: AppBar(
          backgroundColor: background,
          iconTheme: IconThemeData(color: textPrimary),
          title: Text(
            'Carregando...',
            style: TextStyle(
              fontFamily: 'Space Mono',
              fontWeight: FontWeight.bold,
              color: textPrimary,
              fontSize: 16,
            ),
          ),
        ),
        body: Center(child: CircularProgressIndicator(color: colorScheme.primary)),
      );
    }

    if (_errorMessage != null) {
      return Scaffold(
        backgroundColor: background,
        appBar: AppBar(
          backgroundColor: background,
          iconTheme: IconThemeData(color: textPrimary),
          title: Text(
            'Erro',
            style: TextStyle(
              fontFamily: 'Space Mono',
              fontWeight: FontWeight.bold,
              color: textPrimary,
              fontSize: 16,
            ),
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              _errorMessage!,
              style: TextStyle(color: textPrimary),
              textAlign: TextAlign.center,
            ),
          ),
        ),
      );
    }

    if (_stepData == null) {
      return Scaffold(
        backgroundColor: background,
        appBar: AppBar(
          backgroundColor: background,
          iconTheme: IconThemeData(color: textPrimary),
          title: Text(
            'Passo não encontrado',
            style: TextStyle(
              fontFamily: 'Space Mono',
              fontWeight: FontWeight.bold,
              color: textPrimary,
              fontSize: 16,
            ),
          ),
        ),
        body: Center(
          child: Text(
            'Detalhes do passo não puderam ser carregados.',
            style: TextStyle(color: textPrimary),
          ),
        ),
      );
    }

    // Smart Fields Replacement
    final userProfile = ref.watch(userProfileProvider).value;
    final companySettings = ref.watch(companySettingsProvider).value;

    String replaceSmartFields(String text) {
      if (text.isEmpty) return text;
      var result = text;

      // User Fields
      if (userProfile != null) {
        final firstName = userProfile.name?.split(' ').first ?? '';
        final lastName = userProfile.name?.split(' ').last ?? '';
        result = result.replaceAll('{{user.firstName}}', firstName);
        result = result.replaceAll('{{user.lastName}}', lastName);
        result = result.replaceAll('{{user.name}}', userProfile.name ?? '');
        result = result.replaceAll('{{user.email}}', userProfile.email ?? '');
      }

      // Company Fields
      if (companySettings != null) {
        result = result.replaceAll('{{company.name}}', companySettings.branding.appTitle);
      }

      return result;
    }

    final title = replaceSmartFields(_stepData!['title'] ?? 'Sem título');
    final contentPayload = _stepData!['contentPayload'] ?? {};
    final htmlContent = replaceSmartFields(contentPayload['htmlContent'] ?? '');
    final imageUrl = contentPayload['imageUrl'];
    
    // New Fields
    final contentType = _stepData!['contentType']?.toString().toUpperCase();
    final formConfig = _stepData!['formConfig'];
    final pollConfig = _stepData!['pollConfig'];
    
    final mediaType = _stepData!['mediaType']?.toString().toUpperCase();
    final mediaUrl = _stepData!['mediaUrl']?.toString();
    final requireAck = _stepData!['requireAck'] == true;
    final isCompleted = _stepData!['completed'] == true;
    
    // Read-only mode passed via extra
    final extra = GoRouterState.of(context).extra as Map<String, dynamic>?;
    final isReadOnly = extra?['isReadOnly'] == true || isCompleted;

    // Check if it's an embedded form/poll
    final isEmbeddedForm = contentType == 'FORM' && formConfig != null;
    final isEmbeddedPoll = contentType == 'POLL' && pollConfig != null;

    return Scaffold(
      backgroundColor: background,
      body: Stack(
        children: [
          // Content
          SingleChildScrollView(
            padding: const EdgeInsets.only(top: 100, bottom: 100), // Space for header and bottom button
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (imageUrl != null && imageUrl.isNotEmpty && mediaType != 'VIDEO')
                  Container(
                    margin: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: Image.network(
                        imageUrl,
                        width: double.infinity,
                        height: 220,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) =>
                            const SizedBox(height: 220, child: Center(child: Icon(Icons.broken_image, size: 50))),
                      ),
                    ),
                  ),

                if (mediaType == 'VIDEO' && mediaUrl != null)
                  Container(
                    margin: const EdgeInsets.all(16),
                    height: 220,
                    decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.play_circle_fill, color: Colors.white, size: 64),
                          const SizedBox(height: 8),
                          Text(
                            'Vídeo: $mediaUrl',
                            style: const TextStyle(color: Colors.white),
                            textAlign: TextAlign.center,
                          ),
                          // TODO: Implement actual video player
                        ],
                      ),
                    ),
                  ),
                
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: theme.textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Space Mono',
                          color: textPrimary,
                          letterSpacing: -1.0,
                        ),
                      ),
                      const SizedBox(height: 24),
                      if (htmlContent.isNotEmpty)
                        HtmlWidget(
                          htmlContent,
                          textStyle: theme.textTheme.bodyLarge?.copyWith(
                            color: textPrimary.withOpacity(0.8),
                            height: 1.6,
                            fontSize: 16,
                          ),
                        ),
                      
                      const SizedBox(height: 32),

                      // Embedded Form
                      if (isEmbeddedForm)
                        FormRenderer(
                          formConfig: formConfig,
                          isReadOnly: isReadOnly,
                          onSubmit: (answers, attachments) {
                            _handleFormSubmit(answers, attachments);
                          },
                        ),

                      // Embedded Poll
                      if (isEmbeddedPoll)
                        SurveyRenderer(
                          surveyConfig: pollConfig,
                          isReadOnly: isReadOnly,
                          onSubmit: (answers) {
                            _completeStepWithData(answers);
                          },
                        ),

                      if (requireAck && !isCompleted && !isEmbeddedForm && !isEmbeddedPoll) ...[
                        const SizedBox(height: 32),
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: colorScheme.surfaceVariant.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: colorScheme.outline.withOpacity(0.2)),
                          ),
                          child: Row(
                            children: [
                              Checkbox(
                                value: _ackChecked,
                                onChanged: (v) => setState(() => _ackChecked = v == true),
                              ),
                              const Expanded(
                                child: Text(
                                  'Li e concordo com o conteúdo acima.',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],

                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Bottom Action Bar (Only for non-embedded or if completed)
          // For embedded, the submit button is inside the renderer
          if (!isEmbeddedForm && !isEmbeddedPoll)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: background,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, -4),
                    ),
                  ],
                ),
                child: SafeArea(
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: (isCompleted || isReadOnly || (requireAck && !_ackChecked)) 
                          ? null 
                          : _completeStep,
                      icon: Icon(isCompleted ? Icons.check : Icons.check_circle, color: Colors.black),
                      label: Text(isCompleted ? 'CONCLUÍDO' : (isReadOnly ? 'JORNADA CONCLUÍDA' : 'MARCAR COMO CONCLUÍDO')),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: colorScheme.secondary,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(vertical: 20),
                        textStyle: const TextStyle(
                          fontFamily: 'Space Mono',
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 0,
                      ),
                    ),
                  ),
                ),
              ),
            ),

          // Glass Header
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(
                  height: 100,
                  padding: const EdgeInsets.fromLTRB(16, 48, 16, 16),
                  decoration: BoxDecoration(
                    color: background.withOpacity(0.8),
                    border: Border(
                      bottom: BorderSide(
                        color: textPrimary.withOpacity(0.05),
                        width: 1,
                      ),
                    ),
                  ),
                  child: Row(
                    children: [
                      IconButton(
                        icon: Icon(Icons.arrow_back, color: textPrimary),
                        onPressed: () => context.pop(),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          title.toString().toUpperCase(),
                          style: TextStyle(
                            fontFamily: 'Space Mono',
                            fontWeight: FontWeight.bold,
                            color: textPrimary,
                            fontSize: 16,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _handleFormSubmit(Map<String, dynamic> answers, List<Map<String, dynamic>> rawAttachments) async {
    setState(() => _isLoading = true);
    try {
      List<Map<String, dynamic>> uploadedAttachments = [];
      
      if (rawAttachments.isNotEmpty) {
        final storage = ref.read(formsStorageProvider);
        // Use linkedFormId or a fallback if not present (though it should be for FORM type)
        // Corrected: Use _stepData instead of widget.step or widget.extra
        final formId = _stepData?['linkedFormId'] ?? 'journey_step_${widget.stepId}';
        
        for (final att in rawAttachments) {
           final path = att['path'] as String?;
           if (path != null) {
             final file = File(path);
             
             // Standardize filename: formTitle_userName_date.ext
             final user = ref.read(userProfileProvider).value;
             final userName = (user?.name ?? user?.email ?? 'unknown').replaceAll(RegExp(r'[^a-zA-Z0-9]'), '_');
             final formTitle = (_stepData?['title'] ?? 'form').toString().replaceAll(RegExp(r'[^a-zA-Z0-9]'), '_');
             final dateStr = DateTime.now().toIso8601String().replaceAll(RegExp(r'[^a-zA-Z0-9]'), '');
             final ext = path.split('.').last;
             final customName = '${formTitle}_${userName}_$dateStr.$ext';

             final uploaded = await storage.uploadFormFile(file, formId: formId, customFileName: customName);
             uploadedAttachments.add(uploaded.toJson());
           }
        }
      }
      
      final data = {
        ...answers,
        'attachments': uploadedAttachments,
      };

      await ref.read(journeyServiceProvider).completeStep(widget.journeyId, widget.stepId, data: data);
      if (mounted) {
        await XPAwardDialog.show(context, 10);
        if (mounted) {
          context.pop();
          ref.invalidate(journeyProgressProvider);
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao enviar: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _completeStepWithData(Map<String, dynamic> data) async {
    setState(() => _isLoading = true);
    try {
      await ref.read(journeyServiceProvider).completeStep(widget.journeyId, widget.stepId, data: data);
      if (mounted) {
        await XPAwardDialog.show(context, 10);
        if (mounted) {
          context.pop();
          ref.invalidate(journeyProgressProvider);
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro ao enviar: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }
}

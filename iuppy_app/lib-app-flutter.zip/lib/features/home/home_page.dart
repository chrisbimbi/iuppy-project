// lib/features/home/home_page.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:iuppy_app/features/home/widgets/glass_search_and_spaces.dart';
import 'package:iuppy_app/features/search/search_bottom_sheet.dart';
import 'package:iuppy_app/push_service.dart';


import '../../core/providers.dart';
import '../forms/providers/forms_provider.dart';
import '../menu/menu_drawer.dart';

import '../surveys/survey_providers.dart';
import '../journeys/journey_providers.dart';
import 'widgets/home_header.dart';
import 'widgets/circular_quick_access.dart';
import 'widgets/news_carousel.dart';
import 'widgets/home_journeys_slider.dart';
import 'widgets/modules_grid.dart';
import 'widgets/curved_navbar.dart';

final _hasAnyNewsCachedProvider = FutureProvider<bool>((ref) async {
  final db = ref.read(dbProvider);
  final items = await db.getNews(limit: 1);
  return items.isNotEmpty;
});

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});
  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  int _navIndex = 0;
  String? _selectedSpaceId;
  String _query = '';

  late final ProviderContainer _c;
  bool _alive = true;

  @override
  void initState() {
    super.initState();
    _c = ProviderScope.containerOf(context, listen: false);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_alive) return;
      _bootstrap();
    });
  }

  @override
  void dispose() {
    _alive = false;
    super.dispose();
  }

  Future<void> _bootstrap() async {
    try {
      await Future.wait([
        _c.read(spacesRepoProvider).fetchAndCache(),
        _c.read(channelsRepoProvider).fetchAndCache(),
        _c.read(companySettingsProvider.future),
      ]);
      
      // Register Push Handler for In-App updates
      PushService.instance.setNotificationRefreshHandler(() async {
         if (!_alive) return;
         await _refreshLatestNewsAndBadges(); 
         // Force refresh chat specifically
         _c.invalidate(chatBadgeProvider);
         _c.refresh(chatBadgeProvider);
      });

      if (!_alive || !mounted) return;
      await _refreshLatestNewsAndBadges();
      if (!_alive || !mounted) return;
      setState(() {});
    } catch (e, stack) {
      debugPrint('[HOME] Bootstrap ERROR: $e');
      debugPrint('[HOME] Stack: $stack');
    }
  }

  Future<void> _refreshLatestNewsAndBadges() async {
    if (!_alive) return;
    try {
      // 1. Atualiza News
      final api = _c.read(apiClientProvider);
      final remote = await api.getNews();
      if (!_alive) return;
      if (remote.isEmpty) {
        final cachedAll = await _c.read(dbProvider).getNews(limit: 2000);
        final ids = cachedAll
            .map((e) => (e['id'] ?? '').toString())
            .where((id) => id.isNotEmpty)
            .toList();
        if (ids.isNotEmpty) {
          await _c.read(localNewsStoreProvider).markManyRead(ids);
        }
      }
    } catch (_) {}

    await _c.read(newsRepoProvider).homeFeedRemoteFirst(maxItems: 24);
    if (!_alive) return;

    // 2. Força atualização de Surveys e Forms (Garante Badges)
    _c.refresh(surveysListProvider); // 🔥 CORREÇÃO: Busca enquetes na hora
    _c.refresh(formsListProvider);
    _c.refresh(myFormsSubmissionsProvider);
    _c.refresh(journeyProgressProvider);
    _c.refresh(companySettingsProvider); // 🔥 REFRESH SETTINGS (Modules enabled/disabled)

    // 3. Invalida contadores
    _c.invalidate(unreadCountersProvider);
    _c.invalidate(formsBadgesProvider);
    _c.invalidate(newSurveysCountProvider);

    _c.read(feedVersionProvider.notifier).state++;
    _c.read(feedVersionProvider.notifier).state++;
  }

  void _openSearch(String query) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => SearchBottomSheet(initialQuery: query),
    );
  }

  @override
  Widget build(BuildContext context) {
    final branding = ref
        .watch(companySettingsProvider)
        .maybeWhen(data: (d) => d.branding, orElse: () => null);
    final name = ref.watch(authControllerProvider).userName ?? 'usuário';

    final badges = ref.watch(homeBadgesProvider);
    final hasAnyNews = ref
        .watch(_hasAnyNewsCachedProvider)
        .maybeWhen(data: (v) => v, orElse: () => true);

    var unreadNews = ref
        .watch(unreadCountersProvider)
        .maybeWhen(data: (d) => d.total, orElse: () => badges.newsNew);
    if (!hasAnyNews) unreadNews = 0;

    final unreadForms = ref
        .watch(formsBadgesProvider)
        .maybeWhen(data: (v) => v, orElse: () => badges.formsNew);
    final unreadSurveys = ref
        .watch(newSurveysCountProvider)
        .maybeWhen(data: (v) => v, orElse: () => 0);

    final unreadJourneys = ref
        .watch(journeyBadgesProvider)
        .maybeWhen(data: (v) => v, orElse: () => 0);

    final totalAlerts = unreadNews + unreadForms + unreadSurveys + unreadJourneys;

    // Watch chatBadgeProvider and pass badge to CurvedNavbar.
    final chatCount = ref.watch(chatBadgeProvider).value ?? 0;

    final navBarBadges = <int, int>{};
    if (totalAlerts > 0) {
      navBarBadges[2] = totalAlerts; // Notifications index = 2
    }
    if (chatCount > 0) {
      navBarBadges[3] = chatCount; // Chat index = 3
    }

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.grey.shade50,
      drawer: const MenuDrawer(),
      bottomNavigationBar: CurvedNavBar(
        selectedIndex: _navIndex,
        onSelected: (i) {
          setState(() => _navIndex = i);
          switch (i) {
            case 0:
              break;
            case 1:
              GoRouter.of(context).push('/favorites');
              break;
            case 2:
              GoRouter.of(context).push('/notifications');
              break;
            case 3:
              GoRouter.of(context).push('/chat');
              ref.invalidate(chatBadgeProvider); // Invalidate chat badge when chat is opened
              break;
            case 4:
              _scaffoldKey.currentState?.openDrawer();
              break;
          }
        },
        badges: navBarBadges,
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await _refreshLatestNewsAndBadges();
          if (!mounted) return;
          setState(() {});
        },
        child: ListView(
          children: [
            // Header with avatar, greeting, and XP
            const HomeHeader(),
            
            // Circular quick access buttons
            const CircularQuickAccess(),

            // Search and Spaces
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: GlassSearchAndSpaces(
                selectedSpaceId: _selectedSpaceId,
                onSpaceChanged: (id) => setState(() => _selectedSpaceId = id),
                onQueryChanged: (q) => setState(() => _query = q),
                onSearch: _openSearch,
              ),
            ),

            const SizedBox(height: 16),
            
            // News Carousel
            NewsCarousel(spaceId: _selectedSpaceId),

            const SizedBox(height: 16),
            
            // Journeys progress
            const HomeJourneysSlider(),
            
            // Modules section
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Comece agora',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  TextButton(
                    onPressed: () => GoRouter.of(context).push('/modules'),
                    child: const Text('Ver todos'),
                  ),
                ],
              ),
            ),
            
            // Modules slider
            Consumer(
              builder: (context, ref, _) {
                final settings = ref.watch(companySettingsProvider).maybeWhen(
                  data: (d) => d,
                  orElse: () => null,
                );
                final enabled = settings?.enabledModules ?? {};
                final badges = ref.watch(homeBadgesProvider);

                final journeyProgress = ref.watch(journeyProgressProvider).asData?.value ?? [];
                final hasJourneys = journeyProgress.isNotEmpty;

                final items = <_Module>[
                  _Module('surveys', 'Enquetes', Icons.poll_outlined, '/surveys',
                      badge: badges.surveysPending),
                  _Module('activities', 'Atividades', Icons.assignment_outlined, '/activities'),
                  _Module('news', 'Comunicados', Icons.campaign_outlined, '/news',
                      badge: badges.newsNew),
                  _Module('forms', 'Formulários', Icons.assignment_outlined, '/forms',
                      badge: badges.formsNew),
                  _Module('vacations', 'Férias', Icons.beach_access_outlined, '/vacations'),
                  _Module('performance', 'Performance', Icons.trending_up_outlined, '/performance'),
                  if (hasJourneys)
                    _Module('journeys', 'Jornadas', Icons.map_outlined, '/journeys',
                        badge: unreadJourneys),
                ].where((m) => enabled.contains(m.key)).toList();

                return SizedBox(
                  height: 120,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: items.length,
                    itemBuilder: (context, index) {
                      final mod = items[index];
                      return Padding(
                        padding: const EdgeInsets.only(right: 12),
                        child: SizedBox(
                          width: 140,
                          child: _ModuleCard(module: mod),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
            
            const SizedBox(height: 80),
          ],
        ),
      ),
    );
  }
}

class _Module {
  final String key;
  final String label;
  final IconData icon;
  final String route;
  final int badge;
  _Module(this.key, this.label, this.icon, this.route, {this.badge = 0});
}

class _ModuleCard extends StatelessWidget {
  final _Module module;

  const _ModuleCard({required this.module});

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).primaryColor;

    return GestureDetector(
      onTap: () => GoRouter.of(context).push(module.route),
      child: Container(
        decoration: BoxDecoration(
          color: module.key == 'journeys' ? primaryColor : Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    module.icon,
                    size: 32,
                    color: module.key == 'journeys' ? Colors.white : primaryColor,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    module.label,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: module.key == 'journeys' ? Colors.white : Colors.black87,
                    ),
                  ),
                ],
              ),
            ),
            if (module.badge > 0)
              Positioned(
                right: 8,
                top: 8,
                child: Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: Colors.red,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

String _greeting(String name) {
  final hour = DateTime.now().hour;
  if (hour < 12) return 'Bom dia';
  if (hour < 18) return 'Boa tarde';
  return 'Boa noite';
}


import { FC, useState, useEffect } from 'react'
import { useIntl } from 'react-intl'
import Swal from 'sweetalert2'
import { KTSVG } from '../../../../../helpers'
import { ImageUploader } from './ImageUploader'
import { useAuth } from '../../../../modules/auth'
import QuillWrapper from '../../../../../components/QuillWrapper'
import { FormsApi } from '../../../forms/services/api'

import { InlineFormBuilder } from '../InlineFormBuilder'
import { InlinePollBuilder } from '../InlinePollBuilder'

type Props = {
    stepId: string
    initialData: any
    onClose: () => void
    onSave: (data: any) => void
    onDelete: () => void
}

export const StepEditorPanel: FC<Props> = ({ stepId, initialData, onClose, onSave, onDelete }) => {
    const intl = useIntl()
    const { currentUser } = useAuth()
    const [title, setTitle] = useState(initialData?.title || '')
    const [day, setDay] = useState(initialData?.delayDays !== undefined ? initialData.delayDays + 1 : 1)
    const [time, setTime] = useState(initialData?.time || '09:00')
    const [content, setContent] = useState(initialData?.contentPayload?.htmlContent || '')
    const [imageUrl, setImageUrl] = useState(initialData?.contentPayload?.imageUrl || '')
    const [showWidgetPicker, setShowWidgetPicker] = useState(false)

    // New Fields
    const [contentType, setContentType] = useState<'ARTICLE' | 'VIDEO' | 'QUIZ' | 'POLL' | 'FORM'>(initialData?.contentType || 'ARTICLE')
    const [mediaType, setMediaType] = useState<'NONE' | 'IMAGE' | 'VIDEO' | 'DOCUMENT'>(initialData?.mediaType || 'NONE')
    const [mediaUrl, setMediaUrl] = useState(initialData?.mediaUrl || '')
    const [requireAck, setRequireAck] = useState(initialData?.requireAck || false)
    const [linkedFormId, setLinkedFormId] = useState(initialData?.linkedFormId || '')
    const [formConfig, setFormConfig] = useState(initialData?.formConfig || {})
    const [pollConfig, setPollConfig] = useState(initialData?.pollConfig || {})

    // Push Notification Fields
    const [sendPush, setSendPush] = useState(!!initialData?.pushTitle)
    const [pushTitle, setPushTitle] = useState(initialData?.pushTitle || '')
    const [pushMessage, setPushMessage] = useState(initialData?.pushMessage || '')

    const [availableForms, setAvailableForms] = useState<any[]>([])

    // Sync with initialData when it changes (e.g. switching steps)
    useEffect(() => {
        setTitle(initialData?.title || '')
        setTime(initialData?.time || '09:00')
        setContent(initialData?.contentPayload?.htmlContent || '')
        setImageUrl(initialData?.contentPayload?.imageUrl || '')
        setDay(initialData?.delayDays !== undefined ? initialData.delayDays + 1 : 1)
        setContentType(initialData?.contentType || 'ARTICLE')
        setMediaType(initialData?.mediaType || 'NONE')
        setMediaUrl(initialData?.mediaUrl || '')
        setRequireAck(initialData?.requireAck || false)
        setLinkedFormId(initialData?.linkedFormId || '')
        setFormConfig(initialData?.formConfig || {})
        setPollConfig(initialData?.pollConfig || {})

        setSendPush(!!initialData?.pushTitle)
        setPushTitle(initialData?.pushTitle || '')
        setPushMessage(initialData?.pushMessage || '')
    }, [initialData])

    useEffect(() => {
        // Load forms for selection
        if (currentUser?.companyId) {
            FormsApi.list({ companyId: currentUser.companyId })
                .then((res: any) => {
                    setAvailableForms(res.items || [])
                })
                .catch(err => console.error('Failed to load forms', err))
        }
    }, [currentUser])

    const handleSave = () => {
        onSave({
            title,
            time,
            delayDays: day - 1, // Convert back to 0-indexed delay
            contentPayload: {
                htmlContent: content,
                imageUrl: imageUrl
            },
            mediaType,
            mediaUrl,
            requireAck,
            linkedFormId,
            contentType,
            formConfig,
            pollConfig,
            pushTitle: sendPush ? pushTitle : null,
            pushMessage: sendPush ? pushMessage : null
        })
    }

    const insertWidget = (widgetTag: string) => {
        setContent((prev: string) => prev + ` ${widgetTag} `)
        setShowWidgetPicker(false)
    }

    return (
        <div className='bg-white shadow-lg position-fixed top-0 end-0 bottom-0 w-100 mw-900px z-index-drawer d-flex flex-column' style={{ zIndex: 1001 }}>

            {/* Header */}
            <div className='card-header d-flex align-items-center justify-content-between py-4 px-6 border-bottom'>
                <div className='d-flex align-items-center'>
                    <button className='btn btn-icon btn-sm btn-active-light-primary me-3' onClick={onClose}>
                        <KTSVG path='../media/icons/duotune/arrows/arr063.svg' className='svg-icon-1' />
                    </button>
                    <h3 className='card-title m-0'>
                        {intl.formatMessage({ id: 'JOURNEYS.STEP.EDIT' })}
                    </h3>
                </div>
                <div>
                    <button
                        className='btn btn-light-danger me-3'
                        onClick={() => {
                            Swal.fire({
                                title: intl.formatMessage({ id: 'JOURNEYS.STEP.DELETE_CONFIRM_TITLE', defaultMessage: 'Delete Step?' }),
                                text: intl.formatMessage({ id: 'JOURNEYS.STEP.DELETE_CONFIRM_TEXT', defaultMessage: 'Are you sure you want to delete this step? This action cannot be undone.' }),
                                icon: 'warning',
                                showCancelButton: true,
                                confirmButtonColor: '#d33',
                                cancelButtonColor: '#3085d6',
                                confirmButtonText: intl.formatMessage({ id: 'JOURNEYS.STEP.DELETE_CONFIRM_BTN', defaultMessage: 'Yes, delete it!' }),
                                cancelButtonText: intl.formatMessage({ id: 'JOURNEYS.STEP.CANCEL', defaultMessage: 'Cancel' })
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    onDelete()
                                }
                            })
                        }}
                    >
                        {intl.formatMessage({ id: 'JOURNEYS.STEP.DELETE', defaultMessage: 'Delete' })}
                    </button>
                    <button className='btn btn-light me-3' onClick={onClose}>
                        {intl.formatMessage({ id: 'JOURNEYS.STEP.CANCEL' })}
                    </button>
                    <button
                        className='btn btn-primary'
                        onClick={handleSave}
                    >
                        {intl.formatMessage({ id: 'JOURNEYS.STEP.SAVE' })}
                    </button>
                </div>
            </div>

            <div className='d-flex flex-grow-1 overflow-hidden'>

                {/* Left Column: Content */}
                <div className='flex-grow-1 p-8 overflow-auto'>
                    <div className='mb-8'>
                        <label className='form-label fw-bolder text-dark fs-6 required'>
                            {intl.formatMessage({ id: 'JOURNEYS.STEP.TITLE' })}
                        </label>
                        <input
                            type='text'
                            className='form-control form-control-lg form-control-solid'
                            placeholder='Enter step title'
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                        />
                    </div>

                    {/* Content Type Selector */}
                    <div className='mb-8'>
                        <label className='form-label fw-bolder text-dark fs-6'>Content Type</label>
                        <select
                            className='form-select form-select-solid'
                            value={contentType}
                            onChange={(e) => setContentType(e.target.value as any)}
                        >
                            <option value="ARTICLE">Article / Content</option>
                            <option value="FORM">Form</option>
                            <option value="POLL">Poll</option>
                            <option value="VIDEO">Video (Legacy)</option>
                        </select>
                    </div>

                    {contentType === 'ARTICLE' && (
                        <>
                            {/* Media Type Selector */}
                            <div className='mb-8'>
                                <label className='form-label fw-bolder text-dark fs-6'>Media Type</label>
                                <select
                                    className='form-select form-select-solid'
                                    value={mediaType}
                                    onChange={(e) => setMediaType(e.target.value as any)}
                                >
                                    <option value="NONE">None</option>
                                    <option value="IMAGE">Image</option>
                                    <option value="VIDEO">Video</option>
                                    <option value="DOCUMENT">Document</option>
                                </select>
                            </div>

                            {/* Media Input */}
                            {mediaType === 'IMAGE' && (
                                <ImageUploader
                                    label="Header Image"
                                    value={imageUrl}
                                    onUploaded={(url) => {
                                        setImageUrl(url)
                                        setMediaUrl(url)
                                    }}
                                    companyId={currentUser?.companyId || ''}
                                />
                            )}

                            {mediaType === 'VIDEO' && (
                                <div className='mb-8'>
                                    <label className='form-label fw-bold'>Video URL</label>
                                    <input
                                        type='text'
                                        className='form-control form-control-solid'
                                        placeholder='https://...'
                                        value={mediaUrl}
                                        onChange={(e) => setMediaUrl(e.target.value)}
                                    />
                                    <div className='form-text'>Enter the URL of the video (YouTube, Vimeo, or direct link).</div>
                                </div>
                            )}

                            {mediaType === 'DOCUMENT' && (
                                <div className='mb-8'>
                                    <label className='form-label fw-bold'>Document URL</label>
                                    <input
                                        type='text'
                                        className='form-control form-control-solid'
                                        placeholder='https://...'
                                        value={mediaUrl}
                                        onChange={(e) => setMediaUrl(e.target.value)}
                                    />
                                </div>
                            )}

                            <div className='mb-8'>
                                <div className='d-flex justify-content-between align-items-center mb-2'>
                                    <label className='form-label fw-bolder text-dark fs-6'>Step Content</label>
                                    <button
                                        className='btn btn-sm btn-light-warning fw-bold'
                                        onClick={() => setShowWidgetPicker(true)}
                                    >
                                        <i className='bi bi-plus-lg me-1'></i> Widget
                                    </button>
                                </div>

                                <div className='h-400px'>
                                    <QuillWrapper
                                        value={content}
                                        onChange={setContent}
                                        height="350px"
                                    />
                                </div>
                            </div>
                        </>
                    )}

                    {contentType === 'FORM' && (
                        <div className='mb-8'>
                            <InlineFormBuilder
                                value={formConfig}
                                onChange={setFormConfig}
                                locales={['pt-BR', 'en', 'es-ES']}
                            />
                        </div>
                    )}

                    {contentType === 'POLL' && (
                        <div className='mb-8'>
                            <InlinePollBuilder
                                value={pollConfig}
                                onChange={setPollConfig}
                            />
                        </div>
                    )}
                </div>

                {/* Right Column: Settings */}
                <div className='w-300px bg-light border-start p-6 overflow-auto'>

                    <div className='mb-10'>
                        <h4 className='text-dark fw-bolder mb-4'>SCHEDULE</h4>

                        <div className='mb-4'>
                            <label className='form-label fs-7 fw-bold text-muted'>Journey Day</label>
                            <input
                                type='number'
                                className='form-control form-control-sm form-control-solid'
                                value={day}
                                onChange={(e) => setDay(parseInt(e.target.value))}
                                min={1}
                            />
                            <div className='form-text text-muted'>Day 1 is the start of the journey.</div>
                        </div>
                        <div className='mb-4'>
                            <label className='form-label fs-7 fw-bold text-muted'>Time of Day</label>
                            <input
                                type='time'
                                className='form-control form-control-sm form-control-solid'
                                value={time}
                                onChange={(e) => setTime(e.target.value)}
                            />
                        </div>
                    </div>

                    <div className='separator separator-dashed my-8'></div>

                    <div className='mb-10'>
                        <h4 className='text-dark fw-bolder mb-4'>SETTINGS</h4>

                        <div className='d-flex align-items-center justify-content-between mb-4'>
                            <span className='text-gray-800 fw-bold fs-6'>Require Acknowledgment</span>
                            <div className='form-check form-check-solid form-switch'>
                                <input
                                    className='form-check-input'
                                    type='checkbox'
                                    checked={requireAck}
                                    onChange={(e) => setRequireAck(e.target.checked)}
                                />
                            </div>
                        </div>

                        <div className='mb-4'>
                            <div className='d-flex align-items-center justify-content-between mb-2'>
                                <span className='text-gray-800 fw-bold fs-6'>Push Notification</span>
                                <div className='form-check form-check-solid form-switch'>
                                    <input
                                        className='form-check-input'
                                        type='checkbox'
                                        checked={sendPush}
                                        onChange={(e) => setSendPush(e.target.checked)}
                                    />
                                </div>
                            </div>

                            {sendPush && (
                                <div className='ps-4 border-start border-gray-300 ms-2'>
                                    <div className='mb-4'>
                                        <label className='form-label fs-7 fw-bold text-muted'>Push Title</label>
                                        <input
                                            type='text'
                                            className='form-control form-control-sm form-control-solid'
                                            value={pushTitle}
                                            onChange={(e) => setPushTitle(e.target.value)}
                                            placeholder="Notification Title"
                                        />
                                    </div>
                                    <div className='mb-4'>
                                        <label className='form-label fs-7 fw-bold text-muted'>Push Message</label>
                                        <textarea
                                            className='form-control form-control-sm form-control-solid'
                                            rows={3}
                                            value={pushMessage}
                                            onChange={(e) => setPushMessage(e.target.value)}
                                            placeholder="Notification Body"
                                        />
                                    </div>
                                </div>
                            )}
                        </div>

                        <div className='d-flex align-items-center justify-content-between'>
                            <span className='text-gray-800 fw-bold fs-6'>Email Notification</span>
                            <div className='form-check form-check-solid form-switch'>
                                <input className='form-check-input' type='checkbox' />
                            </div>
                        </div>
                    </div>

                </div>

            </div>

            {/* Widget Picker Modal */}
            {showWidgetPicker && (
                <div className='position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center' style={{ zIndex: 1002, backgroundColor: 'rgba(0,0,0,0.5)' }}>
                    <div className='bg-white rounded shadow-lg w-500px'>
                        <div className='card-header d-flex justify-content-between align-items-center p-5 border-bottom'>
                            <h3 className='card-title m-0'>Add Widget</h3>
                            <button className='btn btn-icon btn-sm btn-light' onClick={() => setShowWidgetPicker(false)}>
                                <i className='bi bi-x fs-2'></i>
                            </button>
                        </div>
                        <div className='card-body p-5'>
                            <div className='row g-3'>
                                <div className='col-6'>
                                    <div className='border rounded p-4 text-center hover-elevate-up cursor-pointer bg-light-primary border-primary border-dashed' onClick={() => insertWidget('{{user.firstName}}')}>
                                        <i className='bi bi-person-badge fs-2x text-primary mb-2'></i>
                                        <div className='fw-bold text-gray-800'>User Name</div>
                                        <div className='text-muted fs-7'>Inserts first name</div>
                                    </div>
                                </div>
                                <div className='col-6'>
                                    <div className='border rounded p-4 text-center hover-elevate-up cursor-pointer' onClick={() => insertWidget('{{company.name}}')}>
                                        <i className='bi bi-building fs-2x text-gray-600 mb-2'></i>
                                        <div className='fw-bold text-gray-800'>Company Name</div>
                                        <div className='text-muted fs-7'>Inserts company name</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

        </div>
    )
}

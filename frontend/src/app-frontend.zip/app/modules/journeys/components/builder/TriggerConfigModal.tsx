import { FC, useState } from 'react'
import { KTSVG } from '../../../../../helpers'
import AudiencePicker from '../../../forms/components/AudiencePicker'

type Props = {
    show: boolean
    onClose: () => void
    onSave: (config: any) => void
}

type TriggerType = 'new_users' | 'specific_group' | null

export const TriggerConfigModal: FC<Props> = ({ show, onClose, onSave }) => {
    const [step, setStep] = useState(1)
    const [selectedType, setSelectedType] = useState<'ONBOARDING' | 'DATE_BASED' | null>(null)
    const [audience, setAudience] = useState<{ spaceIds: string[]; groupIds: string[] }>({ spaceIds: [], groupIds: [] })
    const [rejoin, setRejoin] = useState<'continue' | 'restart'>('continue')
    const [startDate, setStartDate] = useState<string>('')

    if (!show) return null

    return (
        <div className='modal fade show d-block' style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
            <div className='modal-dialog modal-dialog-centered mw-800px'>
                <div className='modal-content'>

                    {/* Header */}
                    <div className='modal-header pb-0 border-0 justify-content-end'>
                        <div className='btn btn-sm btn-icon btn-active-color-primary' onClick={onClose}>
                            <KTSVG path='../media/icons/duotune/arrows/arr061.svg' className='svg-icon-1' />
                        </div>
                    </div>

                    {/* Body */}
                    <div className='modal-body scroll-y px-10 px-lg-15 pt-0 pb-15'>

                        {/* Stepper Header */}
                        <div className='mb-13 text-center'>
                            <h1 className='mb-3'>
                                {step === 1 ? 'Select Trigger Type' : 'Configure Audience & Rules'}
                            </h1>
                            <div className='text-muted fw-bold fs-5'>
                                {step === 1
                                    ? 'How should users enter this journey?'
                                    : 'Define who enters and how they progress.'
                                }
                            </div>

                            {/* Stepper Dots */}
                            <div className='d-flex justify-content-center mt-8'>
                                <div className={`w-40px h-40px rounded-circle d-flex align-items-center justify-content-center fw-bolder fs-4 me-5 ${step === 1 ? 'bg-primary text-white' : 'bg-light text-gray-400'}`}>1</div>
                                <div className='h-2px w-50px bg-gray-200 my-auto me-5'></div>
                                <div className={`w-40px h-40px rounded-circle d-flex align-items-center justify-content-center fw-bolder fs-4 ${step === 2 ? 'bg-primary text-white' : 'bg-light text-gray-400'}`}>2</div>
                            </div>
                        </div>

                        {/* Step 1: Selection */}
                        {step === 1 && (
                            <div className='row g-5'>
                                <div className='col-md-6'>
                                    <div
                                        className={`card card-dashed h-100 p-6 cursor-pointer hover-elevate-up ${selectedType === 'ONBOARDING' ? 'border-primary bg-light-primary' : 'border-gray-300'}`}
                                        onClick={() => setSelectedType('ONBOARDING')}
                                    >
                                        <div className='d-flex flex-column align-items-center text-center'>
                                            <KTSVG path='../media/icons/duotune/communication/com013.svg' className='svg-icon-3x mb-5' />
                                            <h3 className='fs-4 fw-bolder mb-2'>Onboarding New Users</h3>
                                            <div className='text-gray-600'>
                                                Automatically starts for new users who match the audience criteria.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className='col-md-6'>
                                    <div
                                        className={`card card-dashed h-100 p-6 cursor-pointer hover-elevate-up ${selectedType === 'DATE_BASED' ? 'border-primary bg-light-primary' : 'border-gray-300'}`}
                                        onClick={() => setSelectedType('DATE_BASED')}
                                    >
                                        <div className='d-flex flex-column align-items-center text-center'>
                                            <KTSVG path='../media/icons/duotune/general/gen014.svg' className='svg-icon-3x mb-5' />
                                            <h3 className='fs-4 fw-bolder mb-2'>Date Based</h3>
                                            <div className='text-gray-600'>
                                                Starts on a specific date for all matching users.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Step 2: Configuration */}
                        {step === 2 && (
                            <div>
                                {selectedType === 'DATE_BASED' && (
                                    <div className='mb-10'>
                                        <label className='form-label fw-bold required'>Start Date</label>
                                        <input
                                            type='datetime-local'
                                            className='form-control form-control-solid'
                                            value={startDate}
                                            onChange={(e) => setStartDate(e.target.value)}
                                        />
                                        <div className='form-text'>The journey will become visible to users on this date.</div>
                                    </div>
                                )}

                                <div className='mb-10'>
                                    <label className='form-label fw-bold'>Target Audience</label>
                                    <AudiencePicker
                                        value={audience}
                                        onChange={setAudience}
                                    />
                                </div>

                                <div className='mb-10'>
                                    <label className='form-label fw-bold mb-5'>Rejoining Policy</label>
                                    <div className='form-check form-check-custom form-check-solid mb-3'>
                                        <input
                                            className='form-check-input'
                                            type='radio'
                                            name='rejoin'
                                            id='rejoin_continue'
                                            checked={rejoin === 'continue'}
                                            onChange={() => setRejoin('continue')}
                                        />
                                        <label className='form-check-label' htmlFor='rejoin_continue'>
                                            User continues the journey (Resume where left off)
                                        </label>
                                    </div>
                                    <div className='form-check form-check-custom form-check-solid'>
                                        <input
                                            className='form-check-input'
                                            type='radio'
                                            name='rejoin'
                                            id='rejoin_restart'
                                            checked={rejoin === 'restart'}
                                            onChange={() => setRejoin('restart')}
                                        />
                                        <label className='form-check-label' htmlFor='rejoin_restart'>
                                            User restarts the journey (Start from beginning)
                                        </label>
                                    </div>
                                </div>
                            </div>
                        )}

                    </div>

                    {/* Footer */}
                    <div className='modal-footer'>
                        <button type='button' className='btn btn-light' onClick={onClose}>Cancel</button>

                        {step === 1 ? (
                            <button
                                type='button'
                                className='btn btn-primary'
                                disabled={!selectedType}
                                onClick={() => setStep(2)}
                            >
                                Next
                            </button>
                        ) : (
                            <div className='d-flex'>
                                <button type='button' className='btn btn-light me-3' onClick={() => setStep(1)}>Back</button>
                                <button
                                    className='btn btn-primary'
                                    onClick={() => {
                                        const config = {
                                            triggerType: selectedType,
                                            targetAudience: audience,
                                            startDate: selectedType === 'DATE_BASED' ? startDate : null,
                                            restartPolicy: rejoin === 'continue' ? 'RESUME' : 'RESTART'
                                        }
                                        onSave(config)
                                    }}
                                >
                                    Done
                                </button>
                            </div>
                        )}
                    </div>

                </div>
            </div>
        </div>
    )
}

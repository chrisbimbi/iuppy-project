// criar este arquivo
import { FC } from 'react'
import { Survey } from 'shared/types/surveys'
import { Link } from 'react-router-dom'

interface Props {
    surveys: Survey[]
    loading: boolean
    onDelete: (id: string) => void
}

const SurveysList: FC<Props> = ({ surveys, loading, onDelete }) => {
    if (loading) return <div>Carregando...</div>
    if (!surveys.length) return <div>Nenhuma enquete encontrada</div>

    return (
        <table className="table">
            <thead>
                <tr>
                    <th>Título</th>
                    <th>Início</th>
                    <th>Fim</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                {surveys.map(s => (
                    <tr key={s.id}>
                        <td>{s.title}</td>
                        <td>{new Date(s.startsAt).toLocaleDateString()}</td>
                        <td>{new Date(s.endsAt).toLocaleDateString()}</td>
                        <td>
                            <Link to={`/surveys/edit/${s.id}`} className="btn btn-sm btn-primary mx-1">
                                Editar
                            </Link>
                            <Link to={`/surveys/${s.id}/statistics`} className="btn btn-sm btn-info mx-1">
                                Estatísticas
                            </Link>
                            <button
                                onClick={() => onDelete(s.id)}
                                className="btn btn-sm btn-danger mx-1"
                            >
                                Excluir
                            </button>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    )
}

export default SurveysList
// criar este arquivo
import { FC, useState } from 'react'
import { CreateSurveyDto, SurveyQuestion } from 'shared/types/surveys'
import SurveyBasicInfo from './SurveyBasicInfo'
import SurveyQuestionsBuilder from './SurveyQuestionsBuilder'

interface Props {
    initialData?: any
    onSubmit: (data: any) => void
    isEdit: boolean
}

const SurveyForm: FC<Props> = ({ initialData, onSubmit, isEdit }) => {
    const [step, setStep] = useState(1)
    const [formValues, setFormValues] = useState<any>(
        initialData ?? {
            title: '',
            description: '',
            adminIds: [],
            spaceIds: [],
            groupIds: [],
            isAnonymous: false,
            startsAt: '',
            endsAt: '',
            questions: [] as SurveyQuestion[],
        }
    )

    const next = (values: any) => {
        setFormValues({ ...formValues, ...values })
        setStep(prev => prev + 1)
    }
    const prev = () => setStep(prev => prev - 1)

    const handleFinish = () => onSubmit(formValues)

    return (
        <div>
            {step === 1 && (
                <SurveyBasicInfo
                    initialValues={formValues}
                    onNext={next}
                    isEdit={isEdit}
                />
            )}
            {step === 2 && (
                <SurveyQuestionsBuilder
                    questions={formValues.questions}
                    onBack={prev}
                    onFinish={handleFinish}
                />
            )}
        </div>
    )
}

export default SurveyForm
import { FC, useEffect } from 'react'
import { useForm, Controller } from 'react-hook-form'
import { useNavigate, useParams } from 'react-router-dom'
import { SurveysService } from '../services/SurveysService'
import {
    CreateSurveyDto,
    UpdateSurveyDto,
    Survey,
} from '@shared/types'
import { SpaceModal } from 'src/app/modules/spaces/components/SpaceModal'
import { GroupModal } from 'src/app/modules/groups/components/GroupModal'
import React from 'react'

export const SurveyFormPage: FC = () => {
    const { companyId, surveyId } = useParams<{
        companyId: string
        surveyId?: string
    }>()
    const navigate = useNavigate()
    const isEdit = Boolean(surveyId)

    const {
        register,
        handleSubmit,
        control,
        reset,
        formState: { isSubmitting },
    } = useForm<CreateSurveyDto>({ defaultValues: {} })

    const [openSpaceModal, setOpenSpaceModal] = React.useState(false)
    const [openGroupModal, setOpenGroupModal] = React.useState(false)

    useEffect(() => {
        if (isEdit && companyId && surveyId) {
            SurveysService.get(companyId, surveyId).then((survey) => {
                reset({
                    title: survey.title,
                    description: survey.description,
                    authorId: survey.authorId,
                    adminIds: survey.adminIds,
                    spaceIds: survey.spaceIds,
                    groupIds: survey.groupIds,
                    isAnonymous: survey.isAnonymous,
                    startsAt: survey.startsAt,
                    endsAt: survey.endsAt,
                    status: survey.status,
                })
            })
        }
    }, [companyId, surveyId])

    const onSubmit = async (data: CreateSurveyDto) => {
        if (!companyId) return
        if (isEdit && surveyId) {
            await SurveysService.update(companyId, surveyId, data)
        } else {
            await SurveysService.create(companyId, data)
        }
        navigate('/surveys')
    }

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="p-4 space-y-4">
            <h1 className="text-xl font-bold">
                {isEdit ? 'Editar Survey' : 'Nova Survey'}
            </h1>

            <Input
                label="Título"
                {...register('title', { required: true })}
            />

            <Input
                label="Descrição"
                {...register('description')}
            />

            <Input
                label="Author ID"
                {...register('authorId', { required: true })}
            />

            <Controller
                control={control}
                name="adminIds"
                render={({ field }) => (
                    <Select
                        label="Administradores"
                        multiple
                        value={field.value || []}
                        onChange={field.onChange}
                        options={/* importe de groups para popular */}
                    />
                )}
            />

            <Button onClick={() => setOpenSpaceModal(true)}>
                Selecionar Espaços
            </Button>
            <SpaceModal
                isOpen={openSpaceModal}
                onSelect={(ids) => {
                    control.setValue('spaceIds', ids)
                    setOpenSpaceModal(false)
                }}
                onClose={() => setOpenSpaceModal(false)}
                companyId={companyId!}
                multiple
            />

            <Button onClick={() => setOpenGroupModal(true)}>
                Selecionar Grupos
            </Button>
            <GroupModal
                isOpen={openGroupModal}
                onSelect={(ids) => {
                    control.setValue('groupIds', ids)
                    setOpenGroupModal(false)
                }}
                onClose={() => setOpenGroupModal(false)}
                companyId={companyId!}
                multiple
            />

            <Checkbox
                label="Anônimo"
                {...register('isAnonymous')}
            />

            <Input
                label="Início (ISO)"
                type="datetime-local"
                {...register('startsAt', { required: true })}
            />

            <Input
                label="Fim (ISO)"
                type="datetime-local"
                {...register('endsAt', { required: true })}
            />

            <Select
                label="Status"
                {...register('status')}
                options={[
                    { value: 'draft', label: 'Draft' },
                    { value: 'published', label: 'Published' },
                    { value: 'archived', label: 'Archived' },
                ]}
            />

            <div className="flex justify-end space-x-2">
                <Button type="button" onClick={() => navigate('/surveys')}>
                    Cancelar
                </Button>
                <Button type="submit" loading={isSubmitting}>
                    Salvar
                </Button>
            </div>
        </form>
    )
}
import { FC, useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { SurveysService } from '../services/SurveysService'
import { Survey } from '@shared/types'
import { Button, Table } from 'bootstrap'
import { SpaceModal } from 'src/app/modules/spaces/components/SpaceModal'
import { GroupModal } from 'src/app/modules/groups/components/GroupModal'

export const SurveysPage: FC = () => {
  const { companyId } = useParams<{ companyId: string }>()
  const navigate = useNavigate()
  const [surveys, setSurveys] = useState<Survey[]>([])
  const [spaceFilter, setSpaceFilter] = useState<string | null>(null)
  const [groupFilter, setGroupFilter] = useState<string | null>(null)
  const [openSpaceModal, setOpenSpaceModal] = useState(false)
  const [openGroupModal, setOpenGroupModal] = useState(false)

  useEffect(() => {
    if (companyId) {
      SurveysService.list(companyId, spaceFilter, groupFilter).then(
        setSurveys
      )
    }
  }, [companyId, spaceFilter, groupFilter])

  return (
    <div className="flex">
      <aside className="w-64 p-4 border-r">
        <h2 className="mb-2 font-semibold">Segmentação</h2>
        <Button
          size="sm"
          onClick={() => setOpenSpaceModal(true)}
          className="mb-2 w-full"
        >
          Espaço: {spaceFilter ?? 'Todos'}
        </Button>
        <Button
          size="sm"
          onClick={() => setOpenGroupModal(true)}
          className="w-full"
        >
          Grupo: {groupFilter ?? 'Todos'}
        </Button>

        <SpaceModal
          isOpen={openSpaceModal}
          onSelect={(id) => {
            setSpaceFilter(id)
            setOpenSpaceModal(false)
          }}
          onClose={() => setOpenSpaceModal(false)}
          companyId={companyId!}
        />

        <GroupModal
          isOpen={openGroupModal}
          onSelect={(id) => {
            setGroupFilter(id)
            setOpenGroupModal(false)
          }}
          onClose={() => setOpenGroupModal(false)}
          companyId={companyId!}
        />
      </aside>

      <main className="flex-1 p-4">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-2xl font-bold">Surveys</h1>
          <Button onClick={() => navigate('surveys/create')}>
            Nova Survey
          </Button>
        </div>

        <Table<Survey>
          data={surveys}
          columns={[
            { header: 'Título', accessor: 'title' },
            {
              header: 'Período',
              accessor: (row) =>
                `${new Date(row.startsAt).toLocaleDateString()} – ${new Date(
                  row.endsAt
                ).toLocaleDateString()}`,
            },
            { header: 'Status', accessor: 'status' },
          ]}
          onRowClick={(row) =>
            navigate(`surveys/${row.id}/statistics`)
          }
          renderActions={(row) => (
            <Button
              size="sm"
              onClick={() => navigate(`surveys/edit/${row.id}`)}
            >
              Editar
            </Button>
          )}
        />
      </main>
    </div>
  )
}
// criar este arquivo
import { FC } from 'react'
import { useParams } from 'react-router-dom'
import { useSurveyStatistics } from '../providers/useSurveys'
import QuestionStats from '../views/SurveyStatistics/QuestionStats'

const COMPANY_ID = '7f64e31e-88cb-4edc-b661-10ebca66880f'

const SurveyStatisticsPage: FC = () => {
    const { surveyId } = useParams<{ surveyId: string }>()
    const { data, isLoading } = useSurveyStatistics({
        companyId: COMPANY_ID,
        surveyId,
    })
    if (isLoading) return <div>Carregando estatísticas...</div>

    return (
        <div className="app-container">
            <h2>Estatísticas da Enquete</h2>
            <div>Total de respostas: {data?.totalResponses}</div>
            {data?.questions.map(q => (
                <QuestionStats key={q.questionId} stats={q} />
            ))}
        </div>
    )
}

export default SurveyStatisticsPage
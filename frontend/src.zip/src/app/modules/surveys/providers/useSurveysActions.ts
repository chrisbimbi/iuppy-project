// criar este arquivo
import { useMutation, useQueryClient } from 'react-query'
import { surveysService } from '../services/SurveysService'
import {
    CreateSurveyDto,
    UpdateSurveyDto,
} from '@shared/types/'

export function useCreateSurvey(companyId: string) {
    const qc = useQueryClient()
    return useMutation(
        (data: CreateSurveyDto) =>
            surveysService.createSurvey({ companyId, data }),
        {
            onSuccess: () => qc.invalidateQueries(['surveys', companyId]),
        }
    )
}

export function useUpdateSurvey(companyId: string) {
    const qc = useQueryClient()
    return useMutation(
        ({
            surveyId,
            data,
        }: {
            surveyId: string
            data: UpdateSurveyDto
        }) =>
            surveysService.updateSurvey({ companyId, surveyId, data }),
        {
            onSuccess: (_res, vars) =>
                qc.invalidateQueries(['survey', companyId, vars.surveyId]),
        }
    )
}

export function useDeleteSurvey(companyId: string) {
    const qc = useQueryClient()
    return useMutation(
        (surveyId: string) =>
            surveysService.deleteSurvey({ companyId, surveyId }),
        {
            onSuccess: () => qc.invalidateQueries(['surveys', companyId]),
        }
    )
}
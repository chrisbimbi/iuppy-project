// criar este arquivo
import { useQuery } from 'react-query'
import { surveysService } from '../services/SurveysService'
import { Survey } from '@shared/types/'

export function useSurveys(options: {
    companyId: string
    spaceId?: string
    groupId?: string
}) {
    const { companyId, spaceId, groupId } = options
    return useQuery<Survey[]>(
        ['surveys', companyId, spaceId, groupId],
        () => surveysService.getSurveys({ companyId, spaceId, groupId })
    )
}

export function useSurvey(options: {
    companyId: string
    surveyId: string
}) {
    const { companyId, surveyId } = options
    return useQuery(
        ['survey', companyId, surveyId],
        () => surveysService.getSurvey({ companyId, surveyId })
    )
}

export function useSurveyStatistics(options: {
    companyId: string
    surveyId: string
}) {
    const { companyId, surveyId } = options
    return useQuery(
        ['surveyStats', companyId, surveyId],
        () =>
            surveysService.getSurveyStats({ companyId, surveyId })
    )
}

export function useQuestionStatistics(options: {
    companyId: string
    questionId: string
}) {
    const { companyId, questionId } = options
    return useQuery(
        ['questionStats', companyId, questionId],
        () =>
            surveysService.getQuestionStats({ companyId, questionId })
    )
}
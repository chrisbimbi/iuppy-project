import axios from 'axios'
import {
    Survey,
    CreateSurveyDto,
    UpdateSurveyDto,
    SurveyStatisticsDto,
    QuestionStatisticsDto,
    CreateSurveyQuestionDto,
    UpdateSurveyQuestionDto,
    CreateSurveyResponseDto,
} from '@shared/types'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:4000'

export const SurveysService = {
    async list(
        companyId: string,
        spaceId?: string | null,
        groupId?: string | null
    ): Promise<Survey[]> {
        const params: Record<string, any> = {}
        if (spaceId) params.spaceId = spaceId
        if (groupId) params.groupId = groupId
        const response = await axios.get<Survey[]>(
            `${API_URL}/modules/${companyId}/surveys`,
            { params }
        )
        return response.data
    },

    async get(companyId: string, surveyId: string): Promise<Survey> {
        const response = await axios.get<Survey>(
            `${API_URL}/modules/${companyId}/surveys/${surveyId}`
        )
        return response.data
    },

    async create(
        companyId: string,
        dto: CreateSurveyDto
    ): Promise<Survey> {
        const response = await axios.post<Survey>(
            `${API_URL}/modules/${companyId}/surveys`,
            dto
        )
        return response.data
    },

    async update(
        companyId: string,
        surveyId: string,
        dto: UpdateSurveyDto
    ): Promise<Survey> {
        const response = await axios.put<Survey>(
            `${API_URL}/modules/${companyId}/surveys/${surveyId}`,
            dto
        )
        return response.data
    },

    async remove(companyId: string, surveyId: string): Promise<void> {
        await axios.delete(
            `${API_URL}/modules/${companyId}/surveys/${surveyId}`
        )
    },

    async getSurveyStats(
        companyId: string,
        surveyId: string
    ): Promise<SurveyStatisticsDto> {
        const response = await axios.get<SurveyStatisticsDto>(
            `${API_URL}/modules/${companyId}/surveys/${surveyId}/statistics`
        )
        return response.data
    },

    async getQuestionStats(
        companyId: string,
        surveyId: string,
        questionId: string
    ): Promise<QuestionStatisticsDto> {
        const response = await axios.get<QuestionStatisticsDto>(
            `${API_URL}/modules/${companyId}/surveys/${surveyId}/questions/${questionId}/statistics`
        )
        return response.data
    },

    // opcional: criar pergunta
    async createQuestion(
        companyId: string,
        surveyId: string,
        dto: CreateSurveyQuestionDto
    ): Promise<void> {
        await axios.post(
            `${API_URL}/modules/${companyId}/surveys/${surveyId}/questions`,
            dto
        )
    },

    // opcional: atualizar pergunta
    async updateQuestion(
        companyId: string,
        questionId: string,
        dto: UpdateSurveyQuestionDto
    ): Promise<void> {
        await axios.put(
            `${API_URL}/modules/${companyId}/surveys/questions/${questionId}`,
            dto
        )
    },

    // opcional: criar resposta
    async createResponse(
        companyId: string,
        surveyId: string,
        dto: CreateSurveyResponseDto
    ): Promise<void> {
        await axios.post(
            `${API_URL}/modules/${companyId}/surveys/${surveyId}/responses`,
            dto
        )
    },
}
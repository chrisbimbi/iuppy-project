import { FC, Suspense } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import TopBarProgress from 'react-topbar-progress-indicator'
import { DashboardWrapper } from '../pages/dashboard/DashboardWrapper'
import { MenuTestPage } from '../pages/MenuTestPage'
import BuilderPageWrapper from '../pages/layout-builder/BuilderPageWrapper'
import ContentPage from 'src/app/modules/communication/controllers/ContentPage'
import GroupsPage from '../modules/groups/controller/GroupsPage'
import ChannelsPage from '../modules/channels/views/ChannelsPage'

import SurveyStatisticsPage from '../modules/surveys/controllers/SurveyStatisticsPage'
import { SurveysPage } from '../modules/surveys/controllers/SurveysPage'
import { SurveyFormPage } from '../modules/surveys/controllers/SurveyFormPage'

const PrivateRoutes: FC = () => {
  return (
    <Suspense fallback={<TopBarProgress />}>
      <Routes>
        <Route index element={<Navigate to="/dashboard" />} />
        <Route path="dashboard" element={<DashboardWrapper />} />
        <Route path="builder" element={<BuilderPageWrapper />} />
        <Route path="menu-test" element={<MenuTestPage />} />

        {/* Conteúdos */}
        <Route path="contents" element={<ContentPage />} />

        {/* Grupos */}
        <Route path="groups" element={<GroupsPage />} />

        {/* Canais */}
        <Route path="channels" element={<ChannelsPage />} />

        {/* Surveys */}
        <Route path="surveys" element={<SurveysPage />} />
        <Route path="surveys/create" element={<SurveyFormPage />} />
        <Route path="surveys/edit/:surveyId" element={<SurveyFormPage />} />
        <Route
          path="surveys/:surveyId/statistics"
          element={<SurveyStatisticsPage />}
        />

        {/* Catch-all */}
        <Route path="*" element={<Navigate to="/error/404" />} />
      </Routes>
    </Suspense>
  )
}

export { PrivateRoutes }
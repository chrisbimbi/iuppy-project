import { DataSource } from 'typeorm';
import * as dotenv from 'dotenv';
import { UserEntity } from '../users/user.entity';
import { Channel } from '../channels/channel.entity';
import { SpaceEntity } from '../spaces/space.entity';
import { NewEntity } from '../news/news.entity';
import { GroupEntity } from 'src/groups/group.entity';
import { SurveyEntity } from 'src/modules/surveys/entities/survey.entity';
import { SurveyQuestionEntity } from 'src/modules/surveys/entities/survey-question.entity';
import { SurveyResponseEntity } from 'src/modules/surveys/entities/survey-response.entity';
import { CompanyEntity } from '../companies/company.entity';
import { CompanySettingsEntity } from 'src/modules/company-settings/company-settings.entity';
import { CompanyModuleEntity } from 'src/modules/company-modules/company-module.entity';

dotenv.config();

export const AppDataSource = new DataSource({
  type: 'postgres',
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT!, 10),
  username: process.env.DB_USERNAME,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  entities: [
    UserEntity,
    Channel,
    SpaceEntity,
    NewEntity,
    GroupEntity,
    SurveyEntity,
    SurveyQuestionEntity,
    SurveyResponseEntity,
    CompanySettingsEntity,
    CompanyModuleEntity,
    CompanyEntity,
  ], migrations: ['src/migrations/*.ts'],
  migrationsTableName: 'migrations',
  synchronize: false,
});

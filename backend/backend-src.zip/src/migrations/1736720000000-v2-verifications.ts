import { MigrationInterface, QueryRunner } from "typeorm";

export class NewsIdempotencyIndexes1736720000000 implements MigrationInterface {
  name = 'NewsIdempotencyIndexes1736720000000'

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS ux_news_open_once
      ON news_interaction_event ("companyId","newsId","userId")
      WHERE "type" = 'OPEN'
    `);
    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS ux_news_ack_once
      ON news_interaction_event ("companyId","newsId","userId")
      WHERE "type" = 'ACK'
    `);
    await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS ux_news_reaction_unique
      ON news_reaction ("companyId","newsId","userId")
    `);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DROP INDEX IF EXISTS ux_news_reaction_unique`);
    await queryRunner.query(`DROP INDEX IF EXISTS ux_news_ack_once`);
    await queryRunner.query(`DROP INDEX IF EXISTS ux_news_open_once`);
  }
}
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

// ENTIDADES
import { NewsEntity } from 'src/news/news.entity';
import { Channel } from 'src/channels/channel.entity'; // ⬅️ necessário p/ FeedService
import { InteractionEventEntity } from '../interactions/entities/interaction-event.entity';
import { NewsReactionEntity } from '../interactions/entities/news-reaction.entity';
import { NewsCommentEntity } from '../interactions/entities/news-comment.entity';
import { NewsShareEntity } from '../interactions/entities/news-share.entity';

// CONTROLLERS
import { NewsV2Controller } from '../news/news.controller';
import { AnalyticsV2Controller } from '../analytics/analytics.controller';
import { MeController } from '../me/me.controller';
import { SpacesV2Controller } from '../spaces/spaces.controller';
import { ChannelsV2Controller } from '../channels/channels.controller';
import { SearchV2Controller } from '../search/search.controller';
import { PushV2Controller } from '../push/push.controller';

// SERVICES
import { NewsV2Service } from '../news/news.service';
import { InteractionsService } from '../interactions/interactions.service';
import { AnalyticsV2Service } from '../analytics/analytics.service';
import { MeService } from '../me/me.service';
import { SpacesV2Service } from '../spaces/spaces.service';
import { ChannelsV2Service } from '../channels/channels.service';
import { SearchV2Service } from '../search/search.service';
import { PushV2Service } from '../push/push.service';
import { FeedService } from '../feed/feed.service';
import { AudienceService } from '../audience/audience.service'; // se seu FeedService injeta

@Module({
  imports: [
    TypeOrmModule.forFeature([
      NewsEntity,
      Channel,
      InteractionEventEntity,
      NewsReactionEntity,
      NewsCommentEntity,
      NewsShareEntity,
    ]),
  ],
  controllers: [
    NewsV2Controller,
    AnalyticsV2Controller,
    MeController,
    SpacesV2Controller,
    ChannelsV2Controller,
    SearchV2Controller,
    PushV2Controller,
  ],
  providers: [
    NewsV2Service,
    InteractionsService,
    AnalyticsV2Service,
    MeService,
    SpacesV2Service,
    ChannelsV2Service,
    SearchV2Service,
    PushV2Service,
    FeedService,
    AudienceService, // se usado pelo FeedService
  ],
  exports: [
    TypeOrmModule,
    InteractionsService,
    FeedService,
  ],
})
export class V2Module {}
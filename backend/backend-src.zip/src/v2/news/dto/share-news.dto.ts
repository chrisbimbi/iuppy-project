import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsIn, IsObject, IsOptional } from 'class-validator';

export class NewsShareDto {
  @ApiPropertyOptional({ enum: ['app', 'email', 'whatsapp', 'telegram'] })
  @IsOptional()
  @IsIn(['app', 'email', 'whatsapp', 'telegram'])
  channel?: 'app' | 'email' | 'whatsapp' | 'telegram';

  @ApiPropertyOptional({ type: 'object' })
  @IsOptional()
  @IsObject()
  meta?: Record<string, any>;
}
import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsUUID, MinLength } from 'class-validator';

export class NewsCommentCreateDto {
  @ApiProperty({ format: 'uuid' })
  @IsUUID()
  newsId!: string;

  @ApiProperty()
  @IsString()
  @MinLength(1)
  text!: string;
}
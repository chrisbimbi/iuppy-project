import { ApiProperty } from '@nestjs/swagger';
import { IsUUID } from 'class-validator';

export class NewsAckDto {
  @ApiProperty({ format: 'uuid' })
  @IsUUID()
  newsId!: string;
}
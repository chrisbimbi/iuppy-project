import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsObject, IsOptional, IsUUID } from 'class-validator';

export class NewsOpenDto {
  @ApiProperty({ format: 'uuid' })
  @IsUUID()
  newsId!: string;

  @ApiPropertyOptional({ type: 'object' })
  @IsOptional()
  @IsObject()
  meta?: Record<string, any>;
}
import { ApiProperty } from '@nestjs/swagger';
import { IsIn, IsUUID } from 'class-validator';
// eslint-disable-next-line @typescript-eslint/consistent-type-imports
import type { ReactionType } from '@shared/types/v2/interactions';

// mantenha esta lista em sincronia com a sua shared
export const REACTIONS: ReactionType[] = [
  'like', 'love', 'clap', 'smile', 'neutral', 'angry',
];

export class NewsReactDto {
  @ApiProperty({ format: 'uuid' })
  @IsUUID()
  newsId!: string;

  @ApiProperty({ enum: REACTIONS })
  @IsIn(REACTIONS)
  reaction!: ReactionType;
}
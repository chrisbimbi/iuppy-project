import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { JwtAccessGuard } from 'src/auth/guards/jwt-access.guard';
import { NewsV2Service } from './news.service';

import { NewsOpenDto } from './dto/open-news.dto';
import { NewsAckDto } from './dto/ack-news.dto';
import { NewsReactDto } from './dto/react-news.dto';
import { NewsCommentCreateDto } from './dto/comment-news.dto';
import { NewsCommentModerateDto } from './dto/moderate-comment.dto';
import { NewsShareDto } from './dto/share-news.dto';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';

@ApiTags('News V2')
@ApiBearerAuth('bearer')
@Controller('v2/news')
@UseGuards(JwtAccessGuard)
export class NewsV2Controller {
  constructor(private readonly svc: NewsV2Service) {}

  @Get(':id')
  detail(@Req() req: any, @Param('id') id: string) {
    const u = req.user;
    return this.svc.detail(u.companyId, id, String(u.sub));
  }

  @Post('open')
  open(@Req() req: any, @Body() dto: NewsOpenDto) {
    const u = req.user;
    return this.svc.open(u.companyId, dto.newsId, String(u.sub), dto.meta);
  }

  @Post('ack')
  ack(@Req() req: any, @Body() dto: NewsAckDto) {
    const u = req.user;
    return this.svc.ack(u.companyId, dto.newsId, String(u.sub));
  }

  @Post('react')
  react(@Req() req: any, @Body() dto: NewsReactDto) {
    const u = req.user;
    return this.svc.react(u.companyId, dto.newsId, String(u.sub), dto.reaction);
  }

  @Post('comment')
  comment(@Req() req: any, @Body() dto: NewsCommentCreateDto) {
    const u = req.user;
    // moderação automática é decidida no service via news.settings.moderateComments
    return this.svc.comment(u.companyId, dto.newsId, String(u.sub), dto.text);
  }

  @Post(':newsId/comments/:commentId/moderate')
  moderate(
    @Req() req: any,
    @Param('newsId') newsId: string,
    @Param('commentId') commentId: string,
    @Body() dto: NewsCommentModerateDto,
  ) {
    const u = req.user;
    return this.svc.moderate(u.companyId, newsId, commentId, !!dto.approve, String(u.sub));
  }

  @Post('share/:newsId')
  share(@Req() req: any, @Param('newsId') newsId: string, @Body() dto: NewsShareDto) {
    const u = req.user;
    return this.svc.share(u.companyId, newsId, String(u.sub), dto.channel ?? 'app', dto.meta);
  }
}
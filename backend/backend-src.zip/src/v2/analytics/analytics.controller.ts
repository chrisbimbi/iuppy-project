import { Controller, Get, Query, Req, UseGuards } from '@nestjs/common';
import { AnalyticsV2Service } from './analytics.service';
import { JwtAccessGuard } from 'src/auth/guards/jwt-access.guard';
// ⚠️ ajuste o import abaixo conforme seu projeto (ex.: '@/auth/jwt-auth.guard' ou 'src/auth/jwt-auth.guard')

@Controller('v2/analytics')
@UseGuards(JwtAccessGuard)
export class AnalyticsV2Controller {
  constructor(private readonly service: AnalyticsV2Service) {}

  @Get('news/summary')
  async newsSummary(
    @Req() req: any,
    @Query('from') from?: string,
    @Query('to') to?: string,
    @Query('newsId') newsId?: string, // opcional: filtra por uma notícia
  ) {
    const companyId = req.user.companyId; // vem do JWT
    return this.service.getNewsSummary(companyId, { from, to, newsId });
  }
}
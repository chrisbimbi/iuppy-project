import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { InjectDataSource } from '@nestjs/typeorm';

type SummaryOpts = { from?: string; to?: string; newsId?: string };

@Injectable()
export class AnalyticsV2Service {
    constructor(@InjectDataSource() private readonly db: DataSource) { }

    private iso(d: Date) { return d.toISOString(); }

    async getNewsSummary(companyId: string, opts: SummaryOpts) {
        try {
            const now = new Date();
            const fromDate = opts.from ? new Date(opts.from) : new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
            const toDate = opts.to ? new Date(opts.to) : now;

            const whereNews = opts.newsId ? ' AND "newsId" = $4' : '';
            const base = [companyId, this.iso(fromDate), this.iso(toDate)];
            const params = opts.newsId ? [...base, opts.newsId] : base;

            // OPEN / ACK / leitores únicos
            const [oa] = await this.db.query(
                `SELECT
           COUNT(*) FILTER (WHERE type='OPEN')::int AS opens,
           COUNT(DISTINCT CASE WHEN type='OPEN' THEN "userId" END)::int AS unique_readers,
           COUNT(*) FILTER (WHERE type='ACK')::int  AS acks
         FROM news_interaction_event
         WHERE "companyId"=$1 AND "createdAt">=$2 AND "createdAt"<$3${whereNews}`,
                params,
            );
            const totals = {
                opens: Number(oa?.opens ?? 0),
                uniqueReaders: Number(oa?.unique_readers ?? 0),
                acks: Number(oa?.acks ?? 0),
            };

            // Reações
            const reactions = await this.db.query(
                `SELECT reaction, COUNT(*)::int AS count
         FROM news_reaction
         WHERE "companyId"=$1 AND "createdAt">=$2 AND "createdAt"<$3${whereNews}
         GROUP BY reaction
         ORDER BY count DESC`,
                params,
            );

            // Comentários
            const [cmt] = await this.db.query(
                `SELECT COUNT(*)::int AS count
         FROM news_comment
         WHERE "companyId"=$1 AND "createdAt">=$2 AND "createdAt"<$3${whereNews}`,
                params,
            );
            const comments = Number(cmt?.count ?? 0);

            // Shares
            const [shr] = await this.db.query(
                `SELECT COUNT(*)::int AS count
         FROM news_share
         WHERE "companyId"=$1 AND "createdAt">=$2 AND "createdAt"<$3${whereNews}`,
                params,
            );
            const shares = Number(shr?.count ?? 0);

            const rates = {
                ackRateOverReaders: totals.uniqueReaders ? totals.acks / totals.uniqueReaders : 0,
                ackRateOverOpens: totals.opens ? totals.acks / totals.opens : 0,
            };

            return {
                range: { from: this.iso(fromDate), to: this.iso(toDate) },
                filter: { newsId: opts.newsId ?? null },
                totals,
                rates,
                reactions,
                comments,
                shares,
            };
        } catch (e) {
            // evita 500 silencioso sem mensagem útil
            throw new InternalServerErrorException('Failed to compute news summary');
        }
    }
}
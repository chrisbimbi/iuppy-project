import { Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';

@Injectable()
export class ChannelsV2Service {
  constructor(private readonly ds: DataSource) {}

  /**
   * Retorna canais ativos da company. Tenta filtrar por membership (user_channel).
   * Se não houver tabela, devolve todos ativos (opcionalmente por spaceId).
   */
  async listVisibleChannels(companyId: string, userId: string, spaceId?: string) {
    const params: any[] = [companyId, userId];
    let filterBySpace = '';
    if (spaceId) {
      filterBySpace = `AND c."spaceId" = $3`;
      params.push(spaceId);
    }

    const sql = `
      WITH has_table AS (
        SELECT to_regclass('public.user_channel') IS NOT NULL AS exists
      )
      SELECT c."id", c."spaceId", c."name", c."slug", c."position"
        FROM "channels" c, has_table ht
       WHERE c."companyId" = $1
         AND COALESCE(c."active", true) = true
         ${filterBySpace}
         AND (
           ht.exists = false
           OR EXISTS (
             SELECT 1 FROM "user_channel" uc
              WHERE uc."companyId" = c."companyId"
                AND uc."channelId" = c."id"
                AND uc."userId" = $2
           )
         )
       ORDER BY c."position" NULLS LAST, c."name" ASC
    `;

    try {
      const rows = await this.ds.query(sql, params);
      return rows;
    } catch {
      const baseParams: any[] = [companyId];
      let where = `WHERE c."companyId" = $1 AND COALESCE(c."active", true) = true`;
      if (spaceId) {
        baseParams.push(spaceId);
        where += ` AND c."spaceId" = $2`;
      }
      const rows = await this.ds.query(
        `SELECT c."id", c."spaceId", c."name", c."slug", c."position"
           FROM "channels" c
          ${where}
          ORDER BY c."position" NULLS LAST, c."name" ASC`,
        baseParams,
      );
      return rows;
    }
  }
}
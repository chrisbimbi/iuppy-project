import { Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';

@Injectable()
export class SpacesV2Service {
  constructor(private readonly ds: DataSource) {}

  /**
   * Retorna espaços ativos da company. Se existir tabela de membership (ex.: user_space),
   * tenta filtrar por pertencimento; caso não exista, retorna todos ativos.
   */
  async listVisibleSpaces(companyId: string, userId: string) {
    // 1) tenta membership (user_space)
    const sqlMembership = `
      WITH has_table AS (
        SELECT to_regclass('public.user_space') IS NOT NULL AS exists
      )
      SELECT s."id", s."name", s."slug", s."position"
        FROM "spaces" s, has_table ht
       WHERE s."companyId" = $1
         AND COALESCE(s."active", true) = true
         AND (
           ht.exists = false
           OR EXISTS (
             SELECT 1 FROM "user_space" us
              WHERE us."companyId" = s."companyId"
                AND us."spaceId" = s."id"
                AND us."userId" = $2
           )
         )
       ORDER BY s."position" NULLS LAST, s."name" ASC
    `;
    try {
      const rows = await this.ds.query(sqlMembership, [companyId, userId]);
      return rows;
    } catch {
      // 2) fallback: sem membership, todos ativos
      const rows = await this.ds.query(
        `SELECT s."id", s."name", s."slug", s."position"
           FROM "spaces" s
          WHERE s."companyId" = $1
            AND COALESCE(s."active", true) = true
          ORDER BY s."position" NULLS LAST, s."name" ASC`,
        [companyId],
      );
      return rows;
    }
  }
}
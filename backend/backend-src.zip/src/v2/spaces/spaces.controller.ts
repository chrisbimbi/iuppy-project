import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { JwtAccessGuard } from 'src/auth/guards/jwt-access.guard';
import { SpacesV2Service } from './spaces.service';
import { ApiBearerAuth, ApiOkResponse, ApiTags } from '@nestjs/swagger';

@ApiTags('Spaces V2')
@ApiBearerAuth('bearer')
@Controller('v2/spaces')
@UseGuards(JwtAccessGuard)
export class SpacesV2Controller {
  constructor(private readonly svc: SpacesV2Service) {}

  @Get()
  @ApiOkResponse({
    description: 'Lista de espaços visíveis ao usuário logado',
    schema: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          id: { type: 'string', format: 'uuid' },
          name: { type: 'string' },
          slug: { type: 'string' },
          position: { type: 'number', nullable: true },
        },
      },
    },
  })
  list(@Req() req: any) {
    const u = req.user;
    return this.svc.listVisibleSpaces(u.companyId, String(u.sub));
  }
}
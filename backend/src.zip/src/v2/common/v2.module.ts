import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'

// ENTITIES base
import { NewsEntity } from 'src/news/news.entity'
import { Channel } from 'src/channels/channel.entity'
import { SpaceEntity } from 'src/spaces/space.entity'
import { UserEntity } from 'src/users/user.entity'

// CONTROLLERS
import { NewsV2Controller } from '../news/news.controller'
import { AnalyticsV2Controller } from '../analytics/analytics.controller'
import { MeController } from '../me/me.controller'
import { SpacesV2Controller } from '../spaces/spaces.controller'
import { ChannelsV2Controller } from '../channels/channels.controller'
import { SearchV2Controller } from '../search/search.controller'
import { PushV2Controller } from '../push/push.controller'
import { InteractionsControllerV2 } from '../interactions/interactions.controller'
import { NewsCommentsControllerV2 } from '../comments/news-comments.controller'
import { NewsPushControllerV2 } from '../news/news-push.controller'

// SERVICES
import { NewsV2Service } from '../news/news.service'
import { InteractionsService } from '../interactions/interactions.service'
import { AnalyticsV2Service } from '../analytics/analytics.service'
import { MeService } from '../me/me.service'
import { SpacesV2Service } from '../spaces/spaces.service'
import { ChannelsV2Service } from '../channels/channels.service'
import { SearchV2Service } from '../search/search.service'
import { PushV2Service } from '../push/push.service'
import { FeedV2Service } from '../feed/feed.service'
import { AudienceService } from '../audience/audience.service'

// NEW/ATUALIZADOS
import { SchemaIntrospectorV2 } from './schema-introspector.v2'
import { MetricsDailyServiceV2 } from '../metrics/metrics-daily.service'
import { CommentCounterAdapterV2 } from '../comments/comment-counter.adapter'

// PUSH NEWS (provider)
import { NewsPushServiceV2 } from '../news/news-push.service'

// NOTIFICATIONS (para CommunicationsService)
import { NotificationsModule } from 'src/notifications/notifications.module'

@Module({
  imports: [
    TypeOrmModule.forFeature([NewsEntity, Channel, SpaceEntity, UserEntity]),
    NotificationsModule, // necessário para injetar CommunicationsService
  ],
  controllers: [
    NewsV2Controller,
    AnalyticsV2Controller,
    MeController,
    SpacesV2Controller,
    ChannelsV2Controller,
    SearchV2Controller,
    PushV2Controller,
    InteractionsControllerV2,
    NewsCommentsControllerV2,
    NewsPushControllerV2,
  ],
  providers: [
    NewsV2Service,
    InteractionsService,
    AnalyticsV2Service,
    MeService,
    SpacesV2Service,
    ChannelsV2Service,
    SearchV2Service,
    PushV2Service,
    FeedV2Service,
    AudienceService,
    SchemaIntrospectorV2,
    CommentCounterAdapterV2,
    MetricsDailyServiceV2,
    NewsPushServiceV2,
  ],
  exports: [
    TypeOrmModule,
    FeedV2Service,
    InteractionsService,
    AudienceService,
    SchemaIntrospectorV2,
    CommentCounterAdapterV2,
    MetricsDailyServiceV2,
  ],
})
export class V2Module {}
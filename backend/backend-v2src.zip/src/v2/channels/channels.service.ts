// src/v2/channels/channels.service.ts
import { Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';

async function regclass(ds: DataSource, name: string) {
  const r = await ds.query(`SELECT to_regclass($1) AS t`, [name]);
  return !!r?.[0]?.t;
}

async function columnExists(ds: DataSource, table: string, column: string) {
  const r = await ds.query(
    `SELECT 1
       FROM information_schema.columns
      WHERE table_schema = 'public' AND table_name = $1 AND column_name = $2
      LIMIT 1`,
    [table, column],
  );
  return r.length > 0;
}

async function pickColumn(ds: DataSource, table: string, candidates: string[]) {
  for (const c of candidates) {
    if (await columnExists(ds, table, c)) return c;
  }
  return null;
}

async function pickAllColumns(ds: DataSource, table: string, candidates: string[]) {
  const found: string[] = [];
  for (const c of candidates) {
    if (await columnExists(ds, table, c)) found.push(c);
  }
  return found;
}

async function countRows(ds: DataSource, table: string, companyCol: string | null, companyId: string) {
  if (companyCol) {
    const r = await ds.query(
      `SELECT 1 FROM "${table}" WHERE "${companyCol}" = $1 LIMIT 1`,
      [companyId],
    );
    return r.length;
  }
  const r = await ds.query(`SELECT 1 FROM "${table}" LIMIT 1`);
  return r.length;
}

async function pickChannelsTable(ds: DataSource, companyId: string) {
  const candidates = ['channel', 'channels', 'channel_entity'];
  const existing: string[] = [];
  for (const t of candidates) {
    if (await regclass(ds, `public.${t}`)) existing.push(t);
  }
  if (existing.length === 0) return null;

  let best: { table: string; rows: number; companyCol: string | null } | null = null;
  for (const t of existing) {
    const companyCol =
      (await pickColumn(ds, t, ['companyId', 'company_id'])) || null;
    const rows = await countRows(ds, t, companyCol, companyId);
    if (!best || rows > best.rows) {
      best = { table: t, rows, companyCol };
    }
  }
  return best;
}

@Injectable()
export class ChannelsV2Service {
  constructor(private readonly ds: DataSource) { }

  /**
   * Lista canais "visíveis ao usuário":
   * - filtra por empresa
   * - considera colunas de status (active/is_published/...); todas que existirem precisam ser verdadeiras
   * - aplica gating por user_channel se houver linhas para o usuário
   * - se vier spaceId, filtra por spaceId (coluna única, array ou pivot) e projeta o mesmo spaceId na resposta
   */
  async listVisibleChannels(companyId: string, userId: string, spaceId?: string) {
    const picked = await pickChannelsTable(this.ds, companyId);
    if (!picked) return [];

    const table = picked.table;
    const companyCol = picked.companyCol || 'companyId';

    const nameCol = (await pickColumn(this.ds, table, ['name'])) || 'name';
    const slugCol = await pickColumn(this.ds, table, ['slug']);
    const positionCol = await pickColumn(this.ds, table, ['position']);

    // Pode haver mais de uma coluna de "status"
    const statusCols = await pickAllColumns(this.ds, table, [
      'active',
      'isPublished',
      'published',
      'is_active',
      'is_published',
    ]);

    const spaceIdCol =
      (await pickColumn(this.ds, table, ['spaceId', 'space_id'])) || null;
    const spaceIdsCol =
      (await pickColumn(this.ds, table, ['spaceIds', 'space_ids'])) || null;

    const hasChannelSpace = await regclass(this.ds, 'public.channel_space');
    const hasSpaceChannel = await regclass(this.ds, 'public.space_channel');
    const pivot = hasChannelSpace ? 'channel_space' : hasSpaceChannel ? 'space_channel' : null;

    // user_channel gating (apenas se houver linhas para o usuário)
    const hasUserChannel = await regclass(this.ds, 'public.user_channel');
    let gateByUser = false;
    let ucCompanyCol = 'companyId';
    let ucUserCol = 'userId';
    let ucChannelCol = 'channelId';

    if (hasUserChannel) {
      ucCompanyCol = (await pickColumn(this.ds, 'user_channel', ['companyId', 'company_id'])) || 'companyId';
      ucUserCol = (await pickColumn(this.ds, 'user_channel', ['userId', 'user_id'])) || 'userId';
      ucChannelCol = (await pickColumn(this.ds, 'user_channel', ['channelId', 'channel_id'])) || 'channelId';

      const r = await this.ds.query(
        `SELECT 1 FROM "user_channel" WHERE "${ucCompanyCol}" = $1 AND "${ucUserCol}" = $2 LIMIT 1`,
        [companyId, userId],
      );
      gateByUser = r.length > 0;
    }

    const filters: string[] = [`c."${companyCol}" = $1`];
    const params: any[] = [companyId];

    // Todas as colunas de status que existirem precisam ser verdadeiras
    for (const sc of statusCols) {
      filters.push(`COALESCE(c."${sc}", true) = true`);
    }

    // Guardaremos o índice do binder que contém o spaceId "simples" para projetar no SELECT
    let bindIndexSpace: number | null = null;

    // --- Filtro por spaceId (correções para text[]/uuid[]/jsonb ou pivot) ---
    if (spaceId) {
      if (spaceIdCol) {
        const idx = params.length + 1;
        filters.push(`c."${spaceIdCol}" = $${idx}`);
        params.push(spaceId);
        bindIndexSpace = idx;
      } else if (spaceIdsCol) {
        // Descobre o tipo da coluna
        const t = await this.ds.query(
          `SELECT data_type, udt_name
             FROM information_schema.columns
            WHERE table_schema='public' AND table_name=$1 AND column_name=$2`,
          [table, spaceIdsCol],
        );
        const udt = t?.[0]?.udt_name as string | undefined; // ex: _uuid, _text
        const isArray = (t?.[0]?.data_type === 'ARRAY') || (udt?.startsWith('_'));

        if (isArray) {
          // ANY em array tipado
          const idx = params.length + 1;
          if (udt === '_uuid') {
            filters.push(`$${idx}::uuid = ANY(c."${spaceIdsCol}")`);
          } else {
            filters.push(`$${idx}::text = ANY(c."${spaceIdsCol}")`);
          }
          params.push(spaceId);
          bindIndexSpace = idx; // podemos projetar a partir deste mesmo parâmetro
        } else {
          // JSON/JSONB: usamos @> com array JSON e adicionamos um binder separado para a projeção
          const idxJson = params.length + 1;
          filters.push(`c."${spaceIdsCol}"::jsonb @> $${idxJson}::jsonb`);
          params.push(JSON.stringify([spaceId]));

          const idxPlain = params.length + 1;
          params.push(spaceId);
          bindIndexSpace = idxPlain;
        }
      } else if (pivot) {
        const pivotHasCompany = await columnExists(this.ds, pivot, companyCol);
        const companyPredicate = pivotHasCompany
          ? `m."${companyCol}" = c."${companyCol}" AND`
          : '';
        const idx = params.length + 1;
        filters.push(`
          EXISTS (
            SELECT 1 FROM "${pivot}" m
             WHERE ${companyPredicate}
                   m."channelId" = c."id"
               AND m."spaceId" = $${idx}
          )
        `);
        params.push(spaceId);
        bindIndexSpace = idx;
      }
    }
    // --- fim do filtro por spaceId ---

    // Monta o SELECT já sabendo se projetaremos um spaceId derivado do filtro
    const selectParts = [
      `c."id"`,
      spaceIdCol
        ? `c."${spaceIdCol}" AS "spaceId"`
        : (bindIndexSpace
          ? `$${bindIndexSpace}::uuid AS "spaceId"`
          : `NULL::uuid AS "spaceId"`),
      `c."${nameCol}" AS "name"`,
      slugCol
        ? `c."${slugCol}" AS "slug"`
        : `LOWER(regexp_replace(c."${nameCol}", '[^a-zA-Z0-9]+', '-', 'g')) AS "slug"`,
      positionCol ? `c."${positionCol}" AS "position"` : `NULL::int AS "position"`,
    ];

    if (gateByUser) {
      const idx = params.length + 1;
      filters.push(`
        EXISTS (
          SELECT 1 FROM "user_channel" uc
           WHERE uc."${ucCompanyCol}" = c."${companyCol}"
             AND uc."${ucChannelCol}" = c."id"
             AND uc."${ucUserCol}" = $${idx}
        )
      `);
      params.push(userId);
    }

    const sql = `
      SELECT ${selectParts.join(', ')}
        FROM "${table}" c
       WHERE ${filters.join(' AND ')}
       ORDER BY "position" NULLS LAST, "name" ASC
    `;

    return this.ds.query(sql, params);
  }
}

import { Inject, Injectable, Logger } from '@nestjs/common';
import { App } from 'firebase-admin/app';
import { getStorage } from 'firebase-admin/storage';
import { FIREBASE_ADMIN } from '../notifications/firebase-admin.provider';

@Injectable()
export class FirebaseStorageService {
    private readonly logger = new Logger(FirebaseStorageService.name);

    constructor(@Inject(FIREBASE_ADMIN) private readonly firebaseApp: App) { }

    async uploadFile(
        fileBuffer: Buffer,
        fileName: string,
        mimeType: string,
        folder: string = 'uploads',
    ): Promise<string> {
        try {
            const bucket = getStorage(this.firebaseApp).bucket();
            const destination = `${folder}/${Date.now()}_${fileName}`;
            const file = bucket.file(destination);

            await file.save(fileBuffer, {
                metadata: {
                    contentType: mimeType,
                },
            });

            // Make it public or use signed URL. For chat/profile images public is often easier if security allows.
            // Alternatively, generate a long-lived signed URL.
            await file.makePublic();
            const publicUrl = file.publicUrl();

            this.logger.log(`File uploaded to ${publicUrl}`);
            return publicUrl;
        } catch (error) {
            this.logger.error(`Error uploading to Firebase Storage: ${error}`);
            throw error;
        }
    }
}

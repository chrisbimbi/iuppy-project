export class NewsAckDto {}

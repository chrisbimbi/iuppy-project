import { Injectable, Logger } from '@nestjs/common'
import { DataSource } from 'typeorm'

type EventMap = {
  table: 'news_interaction_event' | 'interaction_event'
  typeCol: 'type' | 'event'
  newsIdCol: 'newsId' | 'objectId'
  createdAtCol: 'createdAt' | 'created_at'
}

type CommentMap = {
  table: 'news_comment'
  approvedCol?: 'approved'
  statusCol?: 'status'
  createdAtCol: 'createdAt' | 'created_at'
}

@Injectable()
export class SchemaIntrospectorV2 {
  private readonly logger = new Logger(SchemaIntrospectorV2.name)
  constructor(private readonly ds: DataSource) {}

  // === Wrappers públicos para compatibilidade com chamadas existentes ===
  async hasTable(table: string): Promise<boolean> { return this.tableExists(table) }
  async hasColumn(table: string, column: string): Promise<boolean> { return this.columnExists(table, column) }

  // === Internos ===
  private async tableExists(table: string): Promise<boolean> {
    const q = `SELECT to_regclass($1) IS NOT NULL AS exists`
    const r = await this.ds.query(q, [table])
    return !!r?.[0]?.exists
  }

  private async columnExists(table: string, column: string): Promise<boolean> {
    const q = `
      SELECT 1
      FROM information_schema.columns
      WHERE table_name = $1 AND column_name = $2
      LIMIT 1`
    const r = await this.ds.query(q, [table, column])
    return r.length > 0
  }

  /** Detecta tabela/colunas de eventos OPEN/ACK (variações de schema) */
  async detectEventMap(): Promise<EventMap | null> {
    const candidates = ['news_interaction_event', 'interaction_event'] as const
    for (const table of candidates) {
      if (!(await this.tableExists(table))) continue
      const typeCol =
        (await this.columnExists(table, 'type')) ? 'type'
        : (await this.columnExists(table, 'event')) ? 'event'
        : null
      if (!typeCol) continue
      const newsIdCol =
        (await this.columnExists(table, 'newsId')) ? 'newsId'
        : (await this.columnExists(table, 'objectId')) ? 'objectId'
        : null
      if (!newsIdCol) continue
      const createdAtCol =
        (await this.columnExists(table, 'createdAt')) ? 'createdAt'
        : (await this.columnExists(table, 'created_at')) ? 'created_at'
        : null
      if (!createdAtCol) continue
      return { table, typeCol, newsIdCol, createdAtCol }
    }
    this.logger.warn('Nenhuma tabela de eventos detectada')
    return null
  }

  /** Alias para compatibilidade com chamadas legadas (newsService.detectInteractionEvent) */
  async detectInteractionEvent(): Promise<EventMap | null> {
    return this.detectEventMap()
  }

  /** Detecta se comentários usam status (approved/rejected) ou boolean approved */
  async detectCommentMap(): Promise<CommentMap | null> {
    const table = 'news_comment'
    if (!(await this.tableExists(table))) return null
    const approvedCol = (await this.columnExists(table, 'approved')) ? 'approved' : undefined
    const statusCol = !approvedCol && (await this.columnExists(table, 'status')) ? 'status' : undefined
    const createdAtCol =
      (await this.columnExists(table, 'createdAt')) ? 'createdAt'
      : (await this.columnExists(table, 'created_at')) ? 'created_at'
      : 'createdAt'
    return { table, approvedCol, statusCol, createdAtCol }
  }

  /** Retorna o MAX(createdAt) entre tabelas relevantes para compor ETag */
  async getLastUpdateMarker(companyId: string, fromISO?: string, toISO?: string): Promise<string> {
    const pieces: Date[] = []
    const addMax = async (sql: string, params: any[]) => {
      const r = await this.ds.query(sql, params)
      const d = r?.[0]?.max as string | null
      if (d) pieces.push(new Date(d))
    }

    const range = `
      ${fromISO ? 'AND created_at >= $2' : ''}
      ${toISO ? `AND created_at < $${fromISO ? 3 : 2}` : ''}
    `

    // 1) Eventos (OPEN/ACK)
    const ev = await this.detectEventMap()
    if (ev) {
      const sql = `
        SELECT MAX(${ev.createdAtCol}) AS max
        FROM ${ev.table}
        WHERE "companyId" = $1
        ${fromISO || toISO ? range.replace(/created_at/g, ev.createdAtCol) : ''}
      `
      await addMax(sql, [companyId, ...(fromISO ? [fromISO] : []), ...(toISO ? [toISO] : [])])
    }

    // 2) Reactions
    if (await this.tableExists('news_reaction')) {
      const hasCreatedAt = await this.columnExists('news_reaction', 'createdAt')
      const col = hasCreatedAt ? 'createdAt' : 'created_at'
      const sql = `
        SELECT MAX(${col}) AS max
        FROM news_reaction
        WHERE "companyId" = $1
        ${fromISO || toISO ? range.replace(/created_at/g, col) : ''}
      `
      await addMax(sql, [companyId, ...(fromISO ? [fromISO] : []), ...(toISO ? [toISO] : [])])
    }

    // 3) Comments
    const cm = await this.detectCommentMap()
    if (cm) {
      const sql = `
        SELECT MAX(${cm.createdAtCol}) AS max
        FROM ${cm.table}
        WHERE "companyId" = $1
        ${fromISO || toISO ? range.replace(/created_at/g, cm.createdAtCol) : ''}
      `
      await addMax(sql, [companyId, ...(fromISO ? [fromISO] : []), ...(toISO ? [toISO] : [])])
    }

    // 4) Push delivery
    if (await this.tableExists('push_delivery')) {
      const hasDeliveredAt = await this.columnExists('push_delivery', 'deliveredAt')
      const col = hasDeliveredAt ? 'deliveredAt' : 'createdAt'
      const sql = `
        SELECT MAX(${col}) AS max
        FROM push_delivery
        WHERE "companyId" = $1
        ${fromISO || toISO ? range.replace(/created_at/g, col) : ''}
      `
      await addMax(sql, [companyId, ...(fromISO ? [fromISO] : []), ...(toISO ? [toISO] : [])])
    }

    const max = pieces.length ? new Date(Math.max(...pieces.map(d => d.getTime()))) : new Date(0)
    return max.toISOString()
  }
}
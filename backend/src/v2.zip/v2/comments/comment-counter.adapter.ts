import { Injectable } from '@nestjs/common'
import { DataSource } from 'typeorm'
import { SchemaIntrospectorV2 } from '../common/schema-introspector.v2'

@Injectable()
export class CommentCounterAdapterV2 {
  constructor(
    private readonly ds: DataSource,
    private readonly schema: SchemaIntrospectorV2
  ) {}

  /** Alias de compatibilidade (já usado no seu service) */
  async countApprovedForNews(companyId: string, newsId: string): Promise<number> {
    const map = await this.schema.detectCommentMap()
    if (!map) return 0

    if (map.approvedCol) {
      const sql = `
        SELECT COUNT(*)::int AS c
        FROM ${map.table}
        WHERE "companyId" = $1 AND "newsId" = $2 AND "${map.approvedCol}" = true
      `
      const r = await this.ds.query(sql, [companyId, newsId])
      return r?.[0]?.c ?? 0
    }

    if (map.statusCol) {
      const sql = `
        SELECT COUNT(*)::int AS c
        FROM ${map.table}
        WHERE "companyId" = $1 AND "newsId" = $2 AND "${map.statusCol}" = 'APPROVED'
      `
      const r = await this.ds.query(sql, [companyId, newsId])
      return r?.[0]?.c ?? 0
    }

    return 0
  }

  /** Alias de compatibilidade (já usado no seu service) */
  async countApprovedByUserForNews(companyId: string, userId: string, newsId: string): Promise<number> {
    const map = await this.schema.detectCommentMap()
    if (!map) return 0

    if (map.approvedCol) {
      const sql = `
        SELECT COUNT(*)::int AS c
        FROM ${map.table}
        WHERE "companyId" = $1 AND "userId" = $2 AND "newsId" = $3 AND "${map.approvedCol}" = true
      `
      const r = await this.ds.query(sql, [companyId, userId, newsId])
      return r?.[0]?.c ?? 0
    }

    if (map.statusCol) {
      const sql = `
        SELECT COUNT(*)::int AS c
        FROM ${map.table}
        WHERE "companyId" = $1 AND "userId" = $2 AND "newsId" = $3 AND "${map.statusCol}" = 'APPROVED'
      `
      const r = await this.ds.query(sql, [companyId, userId, newsId])
      return r?.[0]?.c ?? 0
    }

    return 0
  }

  /** Mantido por retrocompatibilidade (encaminha para countApprovedForNews) */
  async countApproved(companyId: string, newsId: string): Promise<number> {
    return this.countApprovedForNews(companyId, newsId)
  }
}
// src/v2/metrics/metrics-daily.service.ts
import { Injectable, Logger } from '@nestjs/common';
import { DataSource } from 'typeorm';

type EventKind = 'OPEN' | 'ACK' | 'REACT' | 'COMMENT' | 'SHARE';

@Injectable()
export class MetricsDailyServiceV2 {
    private readonly log = new Logger(MetricsDailyServiceV2.name);
    constructor(private readonly ds: DataSource) { }
    private readonly logger = new Logger(MetricsDailyServiceV2.name)

    async bumpNewsCounters(_: {
        companyId: string
        newsId: string
        opened?: number
        acked?: number
        reactions?: number
        commentsApproved?: number
        shares?: number
    }): Promise<void> {
        // no-op por enquanto (stub). Implementar quando quisermos pré-agregar em tempo real.
        return
    }

    async recomputeNewsTotals(_companyId: string, _newsId: string): Promise<void> {
        // no-op
        return
    }


    async onEvent(companyId: string, newsId: string, userId: string, kind: EventKind) {
        // no-op rápido se tabela não existir (mantém boot barato)
        const exists = await this.ds.query(`SELECT to_regclass('public.news_metrics_daily') AS t`);
        if (!exists?.[0]?.t) return;

        const d = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
        const cols: Record<EventKind, string> = {
            OPEN: 'opens_total',
            ACK: 'acks_total',
            REACT: 'reactions_total',
            COMMENT: 'comments_total_approved',
            SHARE: 'shares_total',
        };
        const col = cols[kind];

        await this.ds.query(
            `INSERT INTO news_metrics_daily ("date","companyId","newsId","${col}")
       VALUES ($1,$2,$3,1)
       ON CONFLICT ("date","companyId","newsId")
       DO UPDATE SET "${col}" = COALESCE(news_metrics_daily."${col}",0) + 1`,
            [d, companyId, newsId],
        ).catch(() => { });
    }
}